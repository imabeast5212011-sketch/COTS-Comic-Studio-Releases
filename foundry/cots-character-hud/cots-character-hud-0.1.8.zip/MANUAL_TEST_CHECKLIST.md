# Manual Test Checklist

Use a Foundry VTT v14 world running the D&D 5e system.

1. Enable the module and confirm no console-breaking startup errors.
2. As a non-GM player, open HUD configuration and confirm only owned Actors are selectable.
3. Select one main Actor and confirm portrait, name, HP, temp HP, AC, movement, and spell slots or resources display.
4. Change HP, AC, movement, spell slots, or resources on the Actor and confirm the HUD refreshes.
5. Add at least three companion Actors and confirm the tray remains compact and scrolls horizontally.
6. Remove a companion from the tray and confirm the Actor/token still exists.
7. Put selected Actors' tokens on the active scene. Single-click HUD portraits to select, Shift-click to pan, and double-click to open sheets.
8. Assign keybindings in Configure Controls. Hold the main speaker key and confirm other clients see the portrait and name.
9. Release the key and confirm the portrait lingers, fades, and clears.
10. Have two users speak at once and confirm left/right focus presentation.
11. Trigger third and fourth simultaneous speakers and confirm the two newest active speakers stay in focus while displaced active speakers remain marked in the carousel.
12. Accumulate at least nine recent participants and confirm the carousel scrolls, respects the configured maximum, shows overflow, and never duplicates a focused Actor.
13. As GM, drag the bottom overlay dock, open the GM speaker picker, select an NPC, confirm the dock label changes without changing the HUD main Actor, preview locally, hold the GM speaker key, toggle the speaker display off, confirm new presentations stay off, toggle it back on, and use Turn off except GM while a player and GM/NPC speaker are active.
14. As GM, pin the selected NPC, unpin a participant, clear inactive participants, and confirm pinned entries remain visible without displacing active speakers.
15. Configure an Actor cinematic display name, portrait, focus portrait, carousel portrait, short carousel name, focal X/Y, accent color, side preference, and flip state. Confirm the HUD, focus portrait, and carousel use the crop settings and focus portraits auto-flip when placed opposite their preferred side.
16. Post a normal text-box chat message and confirm the speaker and message text briefly appear after send. Click an item or feature from a sheet and confirm the resulting card does not trigger the speaker overlay. Confirm player chat falls back to the sender assigned/HUD actor, GM plain chat uses the GM picker actor before the chat/HUD actor selector, and rolls are ignored.
17. Use the HUD talk opt-out button and confirm manual HUD/keybind presentation does not start for that user. Use the HUD chat opt-out button and confirm that user's future chat messages no longer trigger speaker presentation while other users' chat still works.
18. Enable Auto Voice Presentation, grant microphone permission, speak, and confirm players use their main Actor while GMs use the selected GM speaker actor for scene/NPC voice. Stop speaking and confirm the portrait lingers then fades.
19. Raise Voice Activity Threshold and confirm room noise is less likely to trigger presentation.
20. Disable Manual Speaker Presentation and confirm HUD/keybind presentation does not start while auto voice can still work.
21. Move and resize the speaker overlay and confirm position and width persist after reload.
22. Change overlay gradient, background color, border color, panel opacity, and portrait opacity, then confirm the overlay updates.
23. Toggle reduced animation, carousel, carousel scale, compact carousel, and speaker overlay client settings and confirm they persist.
