import assert from "node:assert/strict";

globalThis.window = {
  innerWidth: 1280,
  innerHeight: 720
};

const { getConstrainedGmDockOffset } = await import("../scripts/settings.js");

assert.deepEqual(getConstrainedGmDockOffset({ left: 0, top: -40 }), { left: 0, top: -40 });

const overlayRect = { left: 120, top: 560 };
const dockRect = { width: 420, height: 38 };
const dock = getConstrainedGmDockOffset({ left: -9999, top: 9999 }, { overlayRect, dockRect });

const dockLeft = overlayRect.left + dock.left;
const dockTop = overlayRect.top + dock.top;
assert.ok(dockLeft >= 8);
assert.ok(dockTop >= 8);
assert.ok(dockLeft + dockRect.width <= window.innerWidth - 8);
assert.ok(dockTop + dockRect.height <= window.innerHeight - 8);

console.log("GM dock offset tests passed");
