import assert from "node:assert/strict";
import { deriveParticipantLayout, participantKeysToForget } from "../scripts/participant-layout.js";

function participant(key, patch = {}) {
  return {
    key,
    actorUuid: key,
    userId: `user-${key}`,
    active: false,
    pinned: false,
    startedAt: 0,
    lastActiveAt: 0,
    sidePreference: "automatic",
    ...patch
  };
}

function keys(entries) {
  return entries.map(entry => entry.key);
}

const conversation = new Map();
conversation.set("A", participant("A", { active: true, startedAt: 10, lastActiveAt: 10 }));
let layout = deriveParticipantLayout(conversation.values(), { maxFocus: 2, maxCarousel: 8 });
assert.deepEqual(keys(layout.focus), ["A"]);
assert.deepEqual(keys(layout.carousel), []);

conversation.set("B", participant("B", { active: true, startedAt: 20, lastActiveAt: 20 }));
layout = deriveParticipantLayout(conversation.values(), { maxFocus: 2, maxCarousel: 8 });
assert.deepEqual(keys(layout.focus), ["B", "A"]);

conversation.set("C", participant("C", { active: true, startedAt: 30, lastActiveAt: 30 }));
layout = deriveParticipantLayout(conversation.values(), { maxFocus: 2, maxCarousel: 8 });
assert.deepEqual(keys(layout.focus), ["C", "B"]);
assert.deepEqual(keys(layout.carousel), ["A"]);
assert.equal(layout.carousel[0].active, true);

conversation.set("A", participant("A", { active: false, startedAt: 10, lastActiveAt: 40 }));
conversation.set("D", participant("D", { active: true, startedAt: 50, lastActiveAt: 50 }));
layout = deriveParticipantLayout(conversation.values(), { maxFocus: 2, maxCarousel: 8 });
assert.deepEqual(keys(layout.focus), ["D", "C"]);
assert.ok(!keys(layout.carousel).some(key => keys(layout.focus).includes(key)));

conversation.set("B", participant("B", { active: false, startedAt: 20, lastActiveAt: 55 }));
conversation.set("B", participant("B", { active: true, startedAt: 60, lastActiveAt: 60 }));
layout = deriveParticipantLayout(conversation.values(), { maxFocus: 2, maxCarousel: 8 });
assert.deepEqual(keys(layout.focus), ["B", "D"]);

for (const key of ["E", "F", "G", "H", "I"]) {
  conversation.set(key, participant(key, { active: false, startedAt: key.charCodeAt(0), lastActiveAt: key.charCodeAt(0) }));
}
layout = deriveParticipantLayout(conversation.values(), { maxFocus: 2, maxCarousel: 6 });
assert.equal(layout.carousel.length, 6);
assert.ok(layout.overflowCount > 0);

conversation.set("NPC", participant("NPC", { pinned: true, active: false, startedAt: 1, lastActiveAt: 100 }));
layout = deriveParticipantLayout(conversation.values(), { maxFocus: 2, maxCarousel: 8 });
assert.ok([...layout.focus, ...layout.carousel].some(entry => entry.key === "NPC"));

const forget = participantKeysToForget(conversation.values(), 8);
assert.ok(forget.length > 0);
assert.ok(!forget.includes("NPC"));
assert.ok(!forget.includes("B"));

console.log("participant layout tests passed");
