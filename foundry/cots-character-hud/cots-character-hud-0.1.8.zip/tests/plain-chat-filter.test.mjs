import assert from "node:assert/strict";

const CHAT_TEXT_MAX_LENGTH = 320;

function sanitizeChatText(value) {
  const text = String(value ?? "").replace(/\s+/g, " ").trim();
  if (!text) return "";
  return text.length > CHAT_TEXT_MAX_LENGTH ? `${text.slice(0, CHAT_TEXT_MAX_LENGTH - 3)}...` : text;
}

function stripTags(raw) {
  return String(raw).replace(/<[^>]*>/g, " ");
}

function plainChatTextFromHtml(raw) {
  const text = String(raw ?? "").trim();
  if (!text) return "";
  if (/(class|data-action|data-item-id|data-uuid|<button|<details|<img|<table)/i.test(text)) return "";
  if (/<(?!\/?(br|p|div|span|strong|b|em|i|u|a)\b)[^>]+>/i.test(text)) return "";
  return sanitizeChatText(stripTags(text));
}

assert.equal(plainChatTextFromHtml("hello there"), "hello there");
assert.equal(plainChatTextFromHtml("<p>hello <strong>there</strong></p>"), "hello there");
assert.equal(plainChatTextFromHtml('<div class="dnd5e2 chat-card"><h2>Longsword</h2></div>'), "");
assert.equal(plainChatTextFromHtml('<button data-action="use">Use Item</button>'), "");
assert.equal(plainChatTextFromHtml('<img src="item.webp">Potion'), "");

console.log("plain chat filter tests passed");
