const FOCUS_SIDES = ["left", "right"];

function timeValue(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function stringValue(value) {
  return typeof value === "string" ? value : "";
}

function compareKey(a, b) {
  return stringValue(a.key || a.actorUuid).localeCompare(stringValue(b.key || b.actorUuid));
}

export function compareActiveParticipants(a, b) {
  return timeValue(b.startedAt) - timeValue(a.startedAt)
    || timeValue(b.lastActiveAt) - timeValue(a.lastActiveAt)
    || compareKey(a, b);
}

export function compareRecentParticipants(a, b) {
  return Number(Boolean(b.pinned)) - Number(Boolean(a.pinned))
    || timeValue(b.lastActiveAt) - timeValue(a.lastActiveAt)
    || timeValue(b.startedAt) - timeValue(a.startedAt)
    || compareKey(a, b);
}

export function compareCarouselParticipants(a, b) {
  return Number(Boolean(b.active)) - Number(Boolean(a.active))
    || Number(Boolean(b.pinned)) - Number(Boolean(a.pinned))
    || timeValue(b.lastActiveAt) - timeValue(a.lastActiveAt)
    || timeValue(b.startedAt) - timeValue(a.startedAt)
    || compareKey(a, b);
}

function assignFocusSides(focus) {
  if (focus.length === 0) return [];
  if (focus.length === 1) {
    const preferred = focus[0].sidePreference === "right" ? "right" : "left";
    return [{ ...focus[0], focusSide: preferred }];
  }

  const [first, second] = focus;
  if (first.sidePreference === "right" && second.sidePreference !== "right") {
    return [
      { ...second, focusSide: "left" },
      { ...first, focusSide: "right" }
    ];
  }
  if (first.sidePreference === "left" && second.sidePreference !== "left") {
    return [
      { ...first, focusSide: "left" },
      { ...second, focusSide: "right" }
    ];
  }
  if (second.sidePreference === "left" && first.sidePreference !== "left") {
    return [
      { ...second, focusSide: "left" },
      { ...first, focusSide: "right" }
    ];
  }
  return [
    { ...first, focusSide: "left" },
    { ...second, focusSide: "right" }
  ];
}

export function deriveParticipantLayout(participants, {
  maxFocus = 2,
  maxCarousel = 8,
  showCarousel = true,
  localFocusKey = ""
} = {}) {
  const all = Array.from(participants).filter(participant => participant && participant.key);
  const active = all.filter(participant => participant.active).sort(compareActiveParticipants);
  const recent = all.filter(participant => !participant.active).sort(compareRecentParticipants);
  const focusLimit = Math.max(1, Math.min(2, Math.round(Number(maxFocus) || 2)));
  const focus = active.slice(0, focusLimit);

  if (focus.length < focusLimit) {
    for (const participant of recent) {
      if (focus.some(entry => entry.key === participant.key)) continue;
      focus.push(participant);
      if (focus.length >= focusLimit) break;
    }
  }

  const localFocus = localFocusKey ? all.find(participant => participant.key === localFocusKey) : null;
  if (localFocus && !focus.some(participant => participant.key === localFocus.key)) {
    if (focus.length < focusLimit) focus.push(localFocus);
    else focus[focus.length - 1] = localFocus;
  }

  const focusWithSides = assignFocusSides(focus);
  const focusKeys = new Set(focusWithSides.map(participant => participant.key));
  const carouselCandidates = all
    .filter(participant => !focusKeys.has(participant.key))
    .sort(compareCarouselParticipants);
  const carouselLimit = Math.max(0, Math.round(Number(maxCarousel) || 0));
  const carousel = showCarousel ? carouselCandidates.slice(0, carouselLimit) : [];

  return {
    focus: focusWithSides,
    carousel,
    overflowCount: showCarousel ? Math.max(0, carouselCandidates.length - carousel.length) : carouselCandidates.length
  };
}

export function participantKeysToForget(participants, maxRemembered = 8) {
  const all = Array.from(participants).filter(participant => participant && participant.key);
  const max = Math.max(1, Math.round(Number(maxRemembered) || 8));
  if (all.length <= max) return [];

  const removable = all
    .filter(participant => !participant.active && !participant.pinned)
    .sort((a, b) => timeValue(a.lastActiveAt) - timeValue(b.lastActiveAt) || compareKey(a, b));
  return removable.slice(0, Math.max(0, all.length - max)).map(participant => participant.key);
}
