import { FLAGS, HOOKS, MODULE_ID, SETTINGS, SOCKET_TYPES, TEMPLATES, randomId } from "./constants.js";
import {
  buildActorSnapshot,
  canUserSelectActor,
  getActorStats,
  resolveActorUuid,
  sanitizeActorSnapshot
} from "./actor-data-adapter.js";
import { deriveParticipantLayout, participantKeysToForget } from "./participant-layout.js";
import {
  getCurrentUserConfig,
  getGmSpeakerActorUuid,
  migrateGmSpeakerActorSetting,
  setGmSpeakerActorUuid
} from "./user-config.js";
import {
  getConstrainedGmDockOffset,
  getConstrainedOverlayLayout,
  getGmDockOffset,
  getLingerDuration,
  getMaxSpeakers,
  getMaxConversationParticipants,
  getOverlayAppearance,
  getOverlayLayout,
  getOverlayScale,
  getParticipantCarouselScale,
  getSetting,
  hexToRgb,
  preferCompactParticipantCarousel,
  setGmDockOffset,
  setOverlayLayout,
  setSetting,
  showParticipantCarousel,
  speakerPresentationsPaused,
  usesReducedAnimation
} from "./settings.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

function isObject(value) {
  return value && typeof value === "object" && !Array.isArray(value);
}

const CHAT_TEXT_MAX_LENGTH = 320;

function sanitizeChatText(value) {
  const text = String(value ?? "").replace(/\s+/g, " ").trim();
  if (!text) return "";
  return text.length > CHAT_TEXT_MAX_LENGTH ? `${text.slice(0, CHAT_TEXT_MAX_LENGTH - 3)}...` : text;
}

function chatTextFromMessage(message) {
  const raw = String(message?.content ?? "").trim();
  if (!raw) return "";

  const template = document.createElement("template");
  template.innerHTML = raw;
  return sanitizeChatText(template.content?.textContent ?? raw);
}

function plainChatTextFromMessage(message) {
  const raw = String(message?.content ?? "").trim();
  if (!raw) return "";

  const template = document.createElement("template");
  template.innerHTML = raw;
  const content = template.content;
  const blocked = content.querySelector?.([
    ".card",
    ".chat-card",
    ".dnd5e2",
    ".item-card",
    ".item-name",
    ".item-summary",
    ".item-description",
    "[data-action]",
    "[data-item-id]",
    "[data-uuid]",
    "button",
    "details",
    "img",
    "table"
  ].join(","));
  if (blocked) return "";

  for (const element of content.querySelectorAll?.("*") ?? []) {
    if (!["BR", "P", "DIV", "SPAN", "STRONG", "B", "EM", "I", "U", "A"].includes(element.tagName)) return "";
    if (element.attributes.length > 0 && element.tagName !== "A") return "";
  }

  return sanitizeChatText(content.textContent ?? raw);
}

function actorSpeakerData(actor, snapshot, side) {
  const data = actor ? getActorStats(actor) : sanitizeActorSnapshot(snapshot);
  if (!data) return null;
  const sidePreference = data.sidePreference ?? "automatic";
  const autoFlip = sidePreference === "automatic"
    ? side === "right"
    : Boolean(side && side !== sidePreference);
  const flipPortrait = data.flipPortrait === true ? !autoFlip : autoFlip;
  const name = data.name || "Unknown Speaker";
  const carouselName = data.carouselName || name.split(/\s+/).slice(0, 2).join(" ");
  const focalX = Number.isFinite(data.focalX) ? data.focalX : 50;
  const focalY = Number.isFinite(data.focalY) ? data.focalY : 35;
  return {
    uuid: actor?.uuid ?? data.actorUuid ?? "",
    name,
    carouselName,
    img: data.focusImg || data.img || "icons/svg/mystery-man.svg",
    carouselImg: data.carouselImg || data.img || "icons/svg/mystery-man.svg",
    accentColor: data.accentColor,
    sidePreference,
    flipPortrait,
    focalX,
    focalY,
    portraitPosition: `${focalX}% ${focalY}%`
  };
}

function isNarrativeChatMessage(message) {
  const rolls = message.rolls;
  const rollCount = Array.isArray(rolls) ? rolls.length : rolls?.size ?? 0;
  if (rollCount > 0 || message.isRoll) return false;

  const rollTypes = new Set([
    globalThis.CONST?.CHAT_MESSAGE_TYPES?.ROLL,
    globalThis.CONST?.CHAT_MESSAGE_TYPES?.EMOTE
  ].filter(value => value !== undefined));
  if (rollTypes.has(message.type) && message.type === globalThis.CONST?.CHAT_MESSAGE_TYPES?.ROLL) return false;

  return plainChatTextFromMessage(message).length > 0;
}

function chatUserFromMessage(message, userId) {
  const id = userId || message.user?.id || message.user;
  return id ? game.users.get(id) : null;
}

function userChatPresentationEnabled(user) {
  const config = user?.getFlag?.(MODULE_ID, FLAGS.USER_CONFIG) ?? {};
  return config?.chatPresentationEnabled !== false;
}

async function resolveUserChatActor(user) {
  const character = user?.character;
  if (character?.documentName === "Actor") return character;
  if (typeof character === "string") return game.actors.get(character) ?? null;

  const userConfig = user?.getFlag?.(MODULE_ID, FLAGS.USER_CONFIG) ?? {};
  const mainActorUuid = typeof userConfig.mainActorUuid === "string" ? userConfig.mainActorUuid : "";
  return mainActorUuid ? resolveActorUuid(mainActorUuid) : null;
}

async function chatActorFromMessage(message) {
  const speaker = message.speaker ?? {};
  if (speaker.scene && speaker.token && canvas?.scene?.id === speaker.scene) {
    const token = canvas.tokens?.placeables?.find(placeable => placeable.id === speaker.token || placeable.document?.id === speaker.token);
    if (token?.actor) return token.actor;
  }
  if (speaker.actor) return game.actors.get(speaker.actor) ?? null;
  return null;
}

function participantStateLabel(participant) {
  if (participant.active) return game.i18n.localize(`${MODULE_ID}.participants.speaking`);
  if (participant.pinned) return game.i18n.localize(`${MODULE_ID}.participants.pinned`);
  return game.i18n.localize(`${MODULE_ID}.participants.listening`);
}

function participantTooltip(participant, data) {
  const state = participantStateLabel(participant);
  return participant.pinned
    ? `${data.name} - ${state} (${game.i18n.localize(`${MODULE_ID}.participants.pinned`)})`
    : `${data.name} - ${state}`;
}

export class SpeakerController {
  constructor() {
    this.socketController = null;
    this.element = null;
    this.slots = { left: null, right: null };
    this.participants = new Map();
    this.removeTimers = new Map();
    this.holdState = { main: false, gm: false };
    this.voiceActive = false;
    this.voiceState = null;
    this.toggleMainActive = false;
    this.localFocusKey = "";
    this.remotePresentationsPaused = null;
    this.dragState = null;
    this.gmDockDragState = null;
    this.resizeState = null;
    this._boundRefresh = this._onConfigChanged.bind(this);
    this._boundCanvasReady = this._onCanvasReady.bind(this);
    this._boundUserConnected = this._onUserConnected.bind(this);
    this._boundChatMessage = this._onCreateChatMessage.bind(this);
    this._boundActorDeleted = this._onDeleteActor.bind(this);
    this.gmPicker = null;
  }

  setSocketController(socketController) {
    this.socketController = socketController;
  }

  initialize() {
    if (game.user.isGM) migrateGmSpeakerActorSetting();
    Hooks.on(HOOKS.CONFIG_CHANGED, this._boundRefresh);
    Hooks.on("canvasReady", this._boundCanvasReady);
    Hooks.on("userConnected", this._boundUserConnected);
    Hooks.on("createChatMessage", this._boundChatMessage);
    Hooks.on("deleteActor", this._boundActorDeleted);
    window.addEventListener("resize", this._boundRefresh);
    this.render();
  }

  destroy() {
    Hooks.off(HOOKS.CONFIG_CHANGED, this._boundRefresh);
    Hooks.off("canvasReady", this._boundCanvasReady);
    Hooks.off("userConnected", this._boundUserConnected);
    Hooks.off("createChatMessage", this._boundChatMessage);
    Hooks.off("deleteActor", this._boundActorDeleted);
    window.removeEventListener("resize", this._boundRefresh);
    this.remove();
  }

  async startMainHold() {
    if (!this.#manualPresentationEnabled()) return false;
    if (this.holdState.main) return false;
    this.holdState.main = true;
    const actor = await this.#getMainActor();
    const started = await this.socketController?.emitStart(actor, { mode: "main", source: "hold" });
    if (!started) this.holdState.main = false;
    return Boolean(started);
  }

  async stopMainHold() {
    if (!this.holdState.main) return false;
    this.holdState.main = false;
    const actor = await this.#getMainActor();
    return this.socketController?.emitStop(actor, { mode: "main" }) ?? false;
  }

  async toggleMainPresentation() {
    if (!this.#manualPresentationEnabled()) return false;
    const actor = await this.#getMainActor();
    if (!actor) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.noMainActor`));
      return false;
    }
    if (this.toggleMainActive) {
      this.toggleMainActive = false;
      return this.socketController?.emitStop(actor, { mode: "main" }) ?? false;
    }
    const started = await this.socketController?.emitStart(actor, { mode: "main", source: "toggle" });
    this.toggleMainActive = Boolean(started);
    return Boolean(started);
  }

  async startGmHold() {
    if (!this.#manualPresentationEnabled()) return false;
    if (!game.user.isGM || this.holdState.gm) return false;
    this.holdState.gm = true;
    const actor = await this.#getGmSpeakerActor();
    const started = await this.socketController?.emitStart(actor, { mode: "gm", source: "gm-hold" });
    if (!started) this.holdState.gm = false;
    return Boolean(started);
  }

  async stopGmHold() {
    if (!game.user.isGM || !this.holdState.gm) return false;
    this.holdState.gm = false;
    const actor = await this.#getGmSpeakerActor();
    return this.socketController?.emitStop(actor, { mode: "gm" }) ?? false;
  }

  async previewActor(actor) {
    if (!actor) return;
    const message = this.#buildLocalStartMessage(actor, "preview", "preview");
    await this.#startSpeaker(message, { local: true });
    window.setTimeout(() => this.#stopSpeaker({
      userId: game.user.id,
      actorUuid: actor.uuid,
      linger: getLingerDuration()
    }), 1600);
  }

  async stopAllExceptGm() {
    if (!game.user.isGM) return false;
    const actor = await this.#getGmSpeakerActor();
    return this.socketController?.emitStopExceptGm(actor) ?? false;
  }

  async togglePresentationPaused() {
    if (!game.user.isGM) return false;
    return this.socketController?.emitPresentationPaused(!this.#presentationsPaused()) ?? false;
  }

  async pinCurrentGmSpeaker() {
    if (!game.user.isGM) return false;
    const actor = await this.#getGmSpeakerActor();
    return this.socketController?.emitPinParticipant(actor) ?? false;
  }

  clearInactiveParticipants() {
    if (!game.user.isGM) return false;
    return this.socketController?.emitClearInactiveParticipants() ?? false;
  }

  async startVoiceActivity() {
    if (this.voiceActive) return false;
    this.voiceActive = true;
    const { actor, mode } = await this.#getVoiceActivitySpeaker();
    const started = await this.socketController?.emitStart(actor, { mode, source: "voice" });
    if (started) {
      this.voiceState = { actorUuid: actor.uuid, mode };
    } else {
      this.voiceActive = false;
      this.voiceState = null;
    }
    return Boolean(started);
  }

  async stopVoiceActivity() {
    if (!this.voiceActive) return false;
    this.voiceActive = false;
    const state = this.voiceState;
    this.voiceState = null;
    const actor = state?.actorUuid ? await resolveActorUuid(state.actorUuid) : (await this.#getVoiceActivitySpeaker()).actor;
    return this.socketController?.emitStop(actor, { mode: state?.mode ?? "main" }) ?? false;
  }

  async handleSocketMessage(message, { local = false } = {}) {
    if (!isObject(message) || message.v !== 1 || typeof message.type !== "string") return;
    if (message.type === SOCKET_TYPES.START) {
      await this.#startSpeaker(message, { local });
    } else if (message.type === SOCKET_TYPES.STOP) {
      this.#stopSpeaker(message);
    } else if (message.type === SOCKET_TYPES.STOP_ALL) {
      this.#stopAllSpeakers(message);
    } else if (message.type === SOCKET_TYPES.STOP_EXCEPT_GM) {
      this.#stopExceptGmSpeakers(message);
    } else if (message.type === SOCKET_TYPES.SET_PAUSED) {
      this.#setPresentationsPaused(message);
    } else if (message.type === SOCKET_TYPES.PIN_PARTICIPANT) {
      await this.#pinParticipant(message);
    } else if (message.type === SOCKET_TYPES.UNPIN_PARTICIPANT) {
      await this.#unpinParticipant(message);
    } else if (message.type === SOCKET_TYPES.CLEAR_INACTIVE) {
      this.#clearInactiveParticipants(message);
    }
  }

  async render() {
    if (!this.#overlayEnabled()) {
      this.remove();
      return;
    }

    this.#trimRememberedParticipants();
    const layout = this.#deriveLayout();
    this.#syncSlotsFromLayout(layout.focus);
    const presentationsPaused = this.#presentationsPaused();
    const context = {
      moduleId: MODULE_ID,
      scale: getOverlayScale(),
      carouselScale: getParticipantCarouselScale(),
      reducedMotion: usesReducedAnimation(),
      compactCarousel: preferCompactParticipantCarousel(),
      manualPresentationEnabled: this.#manualPresentationEnabled(),
      presentationsPaused,
      pauseToggleLabel: game.i18n.localize(`${MODULE_ID}.gmSpeaker.${presentationsPaused ? "turnDisplaysOn" : "turnDisplaysOff"}`),
      pauseToggleIcon: presentationsPaused ? "fa-play" : "fa-power-off",
      focusSpeakers: layout.focus.map(participant => this.#participantContext(participant, participant.focusSide, "focus")).filter(Boolean),
      carousel: layout.carousel.map(participant => this.#participantContext(participant, "", "carousel")).filter(Boolean),
      carouselOverflowCount: layout.overflowCount,
      showCarousel: showParticipantCarousel() && (layout.carousel.length > 0 || layout.overflowCount > 0),
      canPinParticipants: this.#canCurrentUserPinParticipants(),
      gm: game.user.isGM,
      gmSelectedName: await this.#getGmSpeakerName()
    };
    const html = await foundry.applications.handlebars.renderTemplate(TEMPLATES.SPEAKER_OVERLAY, context);
    const next = document.createRange().createContextualFragment(html).firstElementChild;
    if (!next) return;

    if (this.element) this.element.replaceWith(next);
    else document.body.appendChild(next);
    this.element = next;
    this.#applyOverlayLayout();
    this.#applyGmDockOffset();
    this.#applyOverlayAppearance();
    this.element.classList.toggle("cots-reduced-motion", usesReducedAnimation());
    this.element.classList.toggle("is-paused", presentationsPaused);
    this.#activateOverlayListeners();
    Hooks.callAll(HOOKS.SPEAKERS_CHANGED, this.participants);
  }

  remove() {
    for (const timer of this.removeTimers.values()) window.clearTimeout(timer);
    this.removeTimers.clear();
    this.element?.remove();
    this.element = null;
  }

  async _onCreateChatMessage(message, options, userId) {
    if (!getSetting(SETTINGS.PRESENT_TEXT_CHAT) || !isNarrativeChatMessage(message)) return;
    const user = chatUserFromMessage(message, userId);
    if (!user) return;
    if (!userChatPresentationEnabled(user)) return;

    const authoredByThisClient = user.id === game.user.id;
    const shouldBroadcastGmChat = authoredByThisClient && game.user.isGM;
    if (!this.#overlayEnabled() && !shouldBroadcastGmChat) return;
    if (user.isGM && !authoredByThisClient) return;

    const chatText = plainChatTextFromMessage(message);
    if (!chatText) return;

    let actor = shouldBroadcastGmChat ? await this.#getGmSpeakerActor() : null;
    if (!actor) actor = await chatActorFromMessage(message);
    if (!actor) actor = await resolveUserChatActor(user);
    if (!actor) return;
    if (!user.isGM && !canUserSelectActor(actor, user)) return;

    const linger = Math.max(getLingerDuration(), 2.5);
    const displayMs = Math.max(2600, Math.min(7000, chatText.length * 55));

    if (shouldBroadcastGmChat) {
      const started = await this.socketController?.emitStart(actor, { mode: "gm", source: "chat-message", chatText, linger });
      if (started) {
        window.setTimeout(() => this.socketController?.emitStop(actor, { mode: "gm", linger }), displayMs);
        return;
      }
    }

    const start = this.#buildLocalStartMessage(actor, "chat", "chat-message", user.id, { chatText });
    await this.#startSpeaker({ ...start, linger }, { local: true, allowInactiveUser: true });
    window.setTimeout(() => this.#stopSpeaker({
      userId: user.id,
      actorUuid: actor.uuid,
      linger
    }), displayMs);
  }

  _onUserConnected(user, connected) {
    if (connected) return;
    for (const [key, participant] of this.participants.entries()) {
      if (participant.userId !== user.id) continue;
      this.#clearTimer(key);
      this.participants.delete(key);
    }
    this.render();
  }

  _onDeleteActor(actor) {
    for (const [key, participant] of this.participants.entries()) {
      if (participant.actorUuid !== actor.uuid) continue;
      this.#clearTimer(key);
      this.participants.delete(key);
    }
    this.render();
  }

  _onConfigChanged(key) {
    if (key === SETTINGS.SPEAKER_PRESENTATIONS_PAUSED) {
      this.remotePresentationsPaused = null;
      if (this.#presentationsPaused()) {
        for (const speaker of this.participants.values()) this.#clearTimer(speaker.key);
        this.participants.clear();
        this.localFocusKey = "";
      }
    }
    this.render();
  }

  _onCanvasReady() {
    const keepPinned = Boolean(getSetting(SETTINGS.PINNED_SURVIVE_SCENE_CHANGE));
    for (const [key, participant] of this.participants.entries()) {
      if (participant.active) continue;
      if (participant.pinned && keepPinned) continue;
      this.#clearTimer(key);
      this.participants.delete(key);
    }
    this.render();
  }

  async #startSpeaker(message, { local = false, allowInactiveUser = false } = {}) {
    if (this.#presentationsPaused() && message.source !== "preview") return;
    const validation = await this.#validateStartMessage(message, { local, allowInactiveUser });
    if (!validation) return;

    const { actor, snapshot, user, chatText } = validation;
    const key = actor?.uuid ?? snapshot.actorUuid;
    const existing = this.participants.get(key);
    const startedAt = Number(message.startedAt) || Date.now();
    if (existing?.stoppedAt && startedAt <= existing.stoppedAt) return;
    this.#clearTimer(key);

    this.participants.set(key, {
      ...existing,
      key,
      actor,
      snapshot,
      actorUuid: key,
      userId: user.id,
      active: true,
      pinned: existing?.pinned === true,
      mode: message.mode,
      chatText,
      startedAt,
      lastActiveAt: Date.now(),
      stoppedAt: null,
      linger: Number(message.linger) || getLingerDuration()
    });
    this.#trimRememberedParticipants();
    await this.render();
  }

  #stopSpeaker(message) {
    const userId = typeof message.userId === "string" ? message.userId : "";
    const actorUuid = typeof message.actorUuid === "string" ? message.actorUuid : "";
    const key = this.#findParticipantKey(actorUuid, userId);
    if (!key) return;
    const speaker = this.participants.get(key);
    if (!speaker) return;

    const stoppedAt = Number(message.stoppedAt) || Date.now();
    if (speaker.startedAt && stoppedAt < speaker.startedAt) return;
    speaker.active = false;
    speaker.stoppedAt = stoppedAt;
    speaker.lastActiveAt = stoppedAt;
    speaker.linger = Number(message.linger) || speaker.linger || getLingerDuration();
    this.#scheduleRemoval(speaker);
    this.render();
  }

  #stopAllSpeakers(message) {
    const user = typeof message.userId === "string" ? game.users.get(message.userId) : null;
    if (!user?.isGM) return;
    for (const speaker of this.participants.values()) this.#clearTimer(speaker.key);
    this.participants.clear();
    this.slots.left = null;
    this.slots.right = null;
    this.localFocusKey = "";
    this.render();
  }

  #stopExceptGmSpeakers(message) {
    const user = typeof message.userId === "string" ? game.users.get(message.userId) : null;
    if (!user?.isGM) return;
    const keepActorUuid = typeof message.actorUuid === "string" ? message.actorUuid : "";

    for (const [key, speaker] of this.participants.entries()) {
      const keepSpeaker = speaker.mode === "gm" || (keepActorUuid && speaker.actorUuid === keepActorUuid);
      if (keepSpeaker) continue;
      this.#clearTimer(speaker.key);
      this.participants.delete(key);
    }
    this.render();
  }

  #setPresentationsPaused(message) {
    const user = typeof message.userId === "string" ? game.users.get(message.userId) : null;
    if (!user?.isGM) return;
    this.remotePresentationsPaused = message.paused === true;
    if (this.remotePresentationsPaused) {
      for (const speaker of this.participants.values()) this.#clearTimer(speaker.key);
      this.participants.clear();
      this.slots.left = null;
      this.slots.right = null;
      this.localFocusKey = "";
    }
    this.render();
  }

  async #pinParticipant(message) {
    const user = typeof message.userId === "string" ? game.users.get(message.userId) : null;
    if (!user) return;

    const actorUuid = typeof message.actorUuid === "string" ? message.actorUuid : "";
    const actor = await resolveActorUuid(actorUuid);
    if (!actor) return;
    if (!user.isGM) {
      if (!getSetting(SETTINGS.ALLOW_PLAYER_PINNING) || !canUserSelectActor(actor, user)) return;
    }

    const snapshot = sanitizeActorSnapshot(message.snapshot) ?? buildActorSnapshot(actor);
    if (!snapshot) return;
    const existing = this.participants.get(actor.uuid);
    this.#clearTimer(actor.uuid);
    this.participants.set(actor.uuid, {
      ...existing,
      key: actor.uuid,
      actor,
      snapshot,
      actorUuid: actor.uuid,
      userId: user.id,
      active: existing?.active === true,
      pinned: true,
      mode: existing?.mode ?? "pin",
      chatText: existing?.chatText ?? "",
      startedAt: existing?.startedAt ?? 0,
      lastActiveAt: Number(message.pinnedAt) || Date.now(),
      stoppedAt: existing?.stoppedAt ?? Date.now(),
      linger: existing?.linger ?? getLingerDuration()
    });
    this.render();
  }

  async #unpinParticipant(message) {
    const user = typeof message.userId === "string" ? game.users.get(message.userId) : null;
    const key = typeof message.actorUuid === "string" ? message.actorUuid : "";
    if (!user || !key) return;
    if (!user.isGM) {
      const actor = await resolveActorUuid(key);
      if (!getSetting(SETTINGS.ALLOW_PLAYER_PINNING) || !actor || !canUserSelectActor(actor, user)) return;
    }
    const participant = this.participants.get(key);
    if (!participant) return;
    participant.pinned = false;
    participant.lastActiveAt = Date.now();
    if (!participant.active) this.#scheduleRemoval(participant);
    this.render();
  }

  #clearInactiveParticipants(message) {
    const user = typeof message.userId === "string" ? game.users.get(message.userId) : null;
    if (!user?.isGM) return;
    for (const [key, participant] of this.participants.entries()) {
      if (participant.active || participant.pinned) continue;
      this.#clearTimer(participant.key);
      this.participants.delete(key);
    }
    if (this.localFocusKey && !this.participants.has(this.localFocusKey)) this.localFocusKey = "";
    this.render();
  }

  async #validateStartMessage(message, { local = false, allowInactiveUser = false } = {}) {
    const user = typeof message.userId === "string" ? game.users.get(message.userId) : null;
    if (!user || (!allowInactiveUser && !local && !user.active)) return null;
    if (message.mode === "gm" && !user.isGM) return null;

    const actorUuid = typeof message.actorUuid === "string" ? message.actorUuid : "";
    const actor = await resolveActorUuid(actorUuid);
    if (!user.isGM && (!actor || !canUserSelectActor(actor, user))) return null;

    const snapshot = user.isGM
      ? sanitizeActorSnapshot(message.snapshot) ?? (actor ? buildActorSnapshot(actor) : null)
      : (actor ? buildActorSnapshot(actor) : null);
    if (!snapshot) return null;
    return { user, actor, snapshot, chatText: sanitizeChatText(message.chatText) };
  }

  #findParticipantKey(actorUuid, userId = "") {
    if (actorUuid && this.participants.has(actorUuid)) return actorUuid;
    for (const participant of this.participants.values()) {
      if (!actorUuid && userId && participant.userId === userId) return participant.key;
      if (actorUuid && participant.actorUuid === actorUuid) return participant.key;
    }
    return "";
  }

  #deriveLayout() {
    return deriveParticipantLayout(this.participants.values(), {
      maxFocus: getMaxSpeakers(),
      maxCarousel: getMaxConversationParticipants(),
      showCarousel: showParticipantCarousel(),
      localFocusKey: this.localFocusKey
    });
  }

  #syncSlotsFromLayout(focus) {
    this.slots.left = focus.find(participant => participant.focusSide === "left") ?? null;
    this.slots.right = focus.find(participant => participant.focusSide === "right") ?? null;
  }

  #participantContext(participant, side = "", variant = "focus") {
    const data = actorSpeakerData(participant.actor, participant.snapshot, side || participant.sidePreference);
    if (!data) return null;
    const state = participantStateLabel(participant);
    const key = participant.key;
    return {
      ...data,
      key,
      actorUuid: participant.actorUuid,
      userId: participant.userId,
      side,
      variant,
      active: participant.active,
      pinned: participant.pinned,
      listening: !participant.active,
      lingering: !participant.active && !participant.pinned,
      mode: participant.mode,
      chatText: variant === "focus" ? participant.chatText : "",
      state,
      tooltip: participantTooltip(participant, data),
      ariaLabel: `${data.name} - ${state}`,
      pinAction: participant.pinned ? "unpin-participant" : "pin-participant",
      pinLabel: game.i18n.localize(`${MODULE_ID}.participants.${participant.pinned ? "unpin" : "pin"}`),
      pinIcon: participant.pinned ? "fa-xmark" : "fa-thumbtack",
      style: `--cots-actor-accent: ${data.accentColor}; --cots-portrait-position: ${data.portraitPosition};`
    };
  }

  #scheduleRemoval(speaker) {
    this.#clearTimer(speaker.key);
    if (speaker.pinned) return;
    const timeout = Math.max(0, speaker.linger * 1000);
    const timer = window.setTimeout(() => {
      const current = this.participants.get(speaker.key);
      if (current && !current.active && !current.pinned) {
        this.participants.delete(speaker.key);
        this.removeTimers.delete(speaker.key);
        if (this.localFocusKey === speaker.key) this.localFocusKey = "";
        this.render();
      }
    }, timeout);
    this.removeTimers.set(speaker.key, timer);
  }

  #clearTimer(key) {
    const timer = this.removeTimers.get(key);
    if (timer) window.clearTimeout(timer);
    this.removeTimers.delete(key);
  }

  #trimRememberedParticipants() {
    const forget = participantKeysToForget(this.participants.values(), getMaxConversationParticipants());
    for (const key of forget) {
      this.#clearTimer(key);
      this.participants.delete(key);
    }
    if (this.localFocusKey && !this.participants.has(this.localFocusKey)) this.localFocusKey = "";
  }

  #presentationsPaused() {
    return this.remotePresentationsPaused ?? speakerPresentationsPaused();
  }

  #canCurrentUserPinParticipants() {
    return game.user.isGM || Boolean(getSetting(SETTINGS.ALLOW_PLAYER_PINNING));
  }

  #activateOverlayListeners() {
    this.element.querySelectorAll("[data-action]").forEach(button => {
      button.addEventListener("click", event => this.#onOverlayAction(event));
    });
    this.element.querySelector("[data-cots-overlay-drag-handle]")?.addEventListener("pointerdown", event => this.#startOverlayDrag(event));
    this.element.querySelector("[data-cots-overlay-resize-handle]")?.addEventListener("pointerdown", event => this.#startOverlayResize(event));
    this.element.querySelector("[data-cots-gm-dock-drag-handle]")?.addEventListener("pointerdown", event => this.#startGmDockDrag(event));
  }

  #onOverlayAction(event) {
    const target = event.currentTarget;
    const action = target?.dataset?.action;
    if (action === "hide-overlay") {
      setSetting(SETTINGS.SPEAKER_OVERLAY_ENABLED, false);
    } else if (action === "open-gm-picker" && game.user.isGM) {
      this.openGmSpeakerPicker();
    } else if (action === "preview-gm" && game.user.isGM) {
      this.#getGmSpeakerActor().then(actor => this.previewActor(actor));
    } else if (action === "stop-all" && game.user.isGM) {
      this.socketController?.emitStopAll();
    } else if (action === "stop-except-gm" && game.user.isGM) {
      this.stopAllExceptGm();
    } else if (action === "toggle-presentation-paused" && game.user.isGM) {
      this.togglePresentationPaused();
    } else if (action === "pin-current-gm" && game.user.isGM) {
      this.pinCurrentGmSpeaker();
    } else if (action === "clear-inactive" && game.user.isGM) {
      this.clearInactiveParticipants();
    } else if (action === "promote-participant") {
      const key = target?.dataset?.participantKey ?? "";
      if (key && this.participants.has(key)) {
        this.localFocusKey = this.localFocusKey === key ? "" : key;
        this.render();
      }
    } else if (action === "pin-participant") {
      const key = target?.dataset?.participantKey ?? "";
      const actor = this.participants.get(key)?.actor;
      this.socketController?.emitPinParticipant(actor);
    } else if (action === "unpin-participant") {
      const key = target?.dataset?.participantKey ?? "";
      this.socketController?.emitUnpinParticipant(key);
    }
  }

  openGmSpeakerPicker() {
    if (!game.user.isGM) return;
    this.gmPicker ??= new GmSpeakerPickerApp(this);
    this.gmPicker.render({ force: true });
  }

  getConversationParticipantContexts() {
    return Array.from(this.participants.values())
      .sort((a, b) => {
        if (a.active !== b.active) return a.active ? -1 : 1;
        if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
        return (b.lastActiveAt ?? 0) - (a.lastActiveAt ?? 0) || a.key.localeCompare(b.key);
      })
      .map(participant => this.#participantContext(participant, "", "list"))
      .filter(Boolean);
  }

  presentationsPaused() {
    return this.#presentationsPaused();
  }

  #overlayEnabled() {
    return Boolean(getSetting(SETTINGS.ENABLE_SPEAKER_OVERLAY)) && Boolean(getSetting(SETTINGS.SPEAKER_OVERLAY_ENABLED));
  }

  #manualPresentationEnabled() {
    return Boolean(getSetting(SETTINGS.MANUAL_PRESENTATION_ENABLED));
  }

  #applyOverlayLayout() {
    const layout = getOverlayLayout();
    this.element.style.left = `${layout.left}px`;
    this.element.style.right = "auto";
    this.element.style.bottom = `${layout.bottom}px`;
    this.element.style.width = `${layout.width}px`;
    this.element.style.setProperty("--cots-overlay-scale", String(getOverlayScale()));
  }

  #applyOverlayAppearance() {
    const appearance = getOverlayAppearance();
    const background = hexToRgb(appearance.backgroundColor);
    this.element.style.setProperty("--cots-overlay-panel-bg", `rgba(${background.r}, ${background.g}, ${background.b}, ${appearance.panelOpacity})`);
    this.element.style.setProperty("--cots-overlay-gradient-start", appearance.gradientStart);
    this.element.style.setProperty("--cots-overlay-gradient-end", appearance.gradientEnd);
    this.element.style.setProperty("--cots-overlay-border-color", appearance.borderColor);
    this.element.style.setProperty("--cots-overlay-portrait-opacity", String(appearance.portraitOpacity));
  }

  #applyGmDockOffset() {
    const dock = this.element?.querySelector("[data-cots-gm-dock]");
    if (!dock) return;
    const offset = getGmDockOffset();
    dock.style.left = `${offset.left}px`;
    dock.style.top = `${offset.top}px`;
  }

  #startOverlayDrag(event) {
    if (event.button !== 0) return;
    event.preventDefault();
    const layout = getOverlayLayout();
    this.dragState = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      layout
    };
    event.currentTarget.setPointerCapture?.(event.pointerId);
    this.element.classList.add("is-moving");
    const move = moveEvent => this.#continueOverlayDrag(moveEvent);
    const up = upEvent => {
      this.#endOverlayDrag(upEvent);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  #continueOverlayDrag(event) {
    if (!this.dragState || event.pointerId !== this.dragState.pointerId) return;
    const next = getConstrainedOverlayLayout({
      ...this.dragState.layout,
      left: this.dragState.layout.left + event.clientX - this.dragState.startX,
      bottom: this.dragState.layout.bottom - (event.clientY - this.dragState.startY)
    });
    this.element.style.left = `${next.left}px`;
    this.element.style.bottom = `${next.bottom}px`;
  }

  #endOverlayDrag(event) {
    if (!this.dragState || event.pointerId !== this.dragState.pointerId) return;
    event.currentTarget.releasePointerCapture?.(event.pointerId);
    const rect = this.element.getBoundingClientRect();
    this.element.classList.remove("is-moving");
    this.dragState = null;
    setOverlayLayout({
      left: rect.left,
      bottom: window.innerHeight - rect.bottom,
      width: rect.width
    });
  }

  #startGmDockDrag(event) {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    const dock = event.currentTarget.closest("[data-cots-gm-dock]");
    if (!dock) return;
    this.gmDockDragState = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      offset: getGmDockOffset(),
      dock
    };
    event.currentTarget.setPointerCapture?.(event.pointerId);
    dock.classList.add("is-moving");
    const move = moveEvent => this.#continueGmDockDrag(moveEvent);
    const up = upEvent => {
      this.#endGmDockDrag(upEvent);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  #continueGmDockDrag(event) {
    if (!this.gmDockDragState || event.pointerId !== this.gmDockDragState.pointerId) return;
    const next = getConstrainedGmDockOffset({
      left: this.gmDockDragState.offset.left + event.clientX - this.gmDockDragState.startX,
      top: this.gmDockDragState.offset.top + event.clientY - this.gmDockDragState.startY
    });
    this.gmDockDragState.dock.style.left = `${next.left}px`;
    this.gmDockDragState.dock.style.top = `${next.top}px`;
  }

  #endGmDockDrag(event) {
    if (!this.gmDockDragState || event.pointerId !== this.gmDockDragState.pointerId) return;
    event.currentTarget.releasePointerCapture?.(event.pointerId);
    const dock = this.gmDockDragState.dock;
    const next = getConstrainedGmDockOffset({
      left: Number.parseFloat(dock.style.left),
      top: Number.parseFloat(dock.style.top)
    });
    dock.classList.remove("is-moving");
    this.gmDockDragState = null;
    setGmDockOffset(next);
  }

  #startOverlayResize(event) {
    if (event.button !== 0) return;
    event.preventDefault();
    const layout = getOverlayLayout();
    this.resizeState = {
      pointerId: event.pointerId,
      startX: event.clientX,
      layout
    };
    event.currentTarget.setPointerCapture?.(event.pointerId);
    this.element.classList.add("is-resizing");
    const move = moveEvent => this.#continueOverlayResize(moveEvent);
    const up = upEvent => {
      this.#endOverlayResize(upEvent);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  #continueOverlayResize(event) {
    if (!this.resizeState || event.pointerId !== this.resizeState.pointerId) return;
    const next = getConstrainedOverlayLayout({
      ...this.resizeState.layout,
      width: this.resizeState.layout.width + event.clientX - this.resizeState.startX
    });
    this.element.style.width = `${next.width}px`;
  }

  #endOverlayResize(event) {
    if (!this.resizeState || event.pointerId !== this.resizeState.pointerId) return;
    event.currentTarget.releasePointerCapture?.(event.pointerId);
    const rect = this.element.getBoundingClientRect();
    this.element.classList.remove("is-resizing");
    this.resizeState = null;
    setOverlayLayout({
      left: rect.left,
      bottom: window.innerHeight - rect.bottom,
      width: rect.width
    });
  }

  async #getMainActor() {
    return resolveActorUuid(getCurrentUserConfig().mainActorUuid);
  }

  async #getGmSpeakerActor() {
    if (!game.user.isGM) return null;
    return resolveActorUuid(getGmSpeakerActorUuid());
  }

  async #getVoiceActivitySpeaker() {
    if (game.user.isGM) {
      const gmActor = await this.#getGmSpeakerActor();
      if (gmActor) return { actor: gmActor, mode: "gm" };
    }
    return { actor: await this.#getMainActor(), mode: "main" };
  }

  async #getGmSpeakerName() {
    const actor = await this.#getGmSpeakerActor();
    return actor?.name ?? game.i18n.localize(`${MODULE_ID}.gmSpeaker.noneSelected`);
  }

  #buildLocalStartMessage(actor, mode, source, userId = game.user.id, { chatText = "" } = {}) {
    return {
      v: 1,
      type: SOCKET_TYPES.START,
      presentationId: randomId(),
      userId,
      actorUuid: actor.uuid,
      mode,
      source,
      startedAt: Date.now(),
      linger: getLingerDuration(),
      snapshot: buildActorSnapshot(actor),
      chatText: sanitizeChatText(chatText)
    };
  }
}

export class GmSpeakerPickerApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: `${MODULE_ID}-gm-speaker-picker`,
    classes: [MODULE_ID, `${MODULE_ID}-gm-speaker-picker`],
    window: {
      title: `${MODULE_ID}.gmSpeaker.title`,
      icon: "fa-solid fa-theater-masks",
      resizable: true
    },
    position: {
      width: 460,
      height: 560
    }
  };

  static PARTS = {
    main: {
      template: TEMPLATES.GM_SPEAKER_PICKER
    }
  };

  constructor(speakerController = game.cotsCharacterHud?.speaker, options = {}) {
    super(options);
    this.speakerController = speakerController;
    this.actorIndex = null;
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    if (!this.actorIndex) this.#buildActorIndex();
    const selected = await resolveActorUuid(getGmSpeakerActorUuid());
    const presentationsPaused = this.speakerController?.presentationsPaused?.() ?? speakerPresentationsPaused();
    return {
      ...context,
      actors: this.actorIndex,
      participants: this.speakerController?.getConversationParticipantContexts?.() ?? [],
      presentationsPaused,
      pauseToggleLabel: game.i18n.localize(`${MODULE_ID}.gmSpeaker.${presentationsPaused ? "turnDisplaysOn" : "turnDisplaysOff"}`),
      pauseToggleIcon: presentationsPaused ? "fa-play" : "fa-power-off",
      selected: selected ? {
        uuid: selected.uuid,
        name: selected.name,
        img: selected.img || "icons/svg/mystery-man.svg"
      } : null
    };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    const search = this.element.querySelector("[data-cots-gm-search]");
    search?.addEventListener("input", event => this.#filterActorRows(event.currentTarget.value));
    this.element.querySelectorAll("[data-cots-action]").forEach(control => {
      control.addEventListener("click", event => this.#onPickerAction(event));
    });
  }

  #buildActorIndex() {
    this.actorIndex = game.actors
      .map(actor => ({
        uuid: actor.uuid,
        name: actor.name,
        type: actor.type,
        img: actor.img || "icons/svg/mystery-man.svg",
        search: `${actor.name} ${actor.type}`.toLocaleLowerCase(game.i18n.lang)
      }))
      .sort((a, b) => a.name.localeCompare(b.name, game.i18n.lang));
  }

  #filterActorRows(query) {
    const needle = String(query ?? "").toLocaleLowerCase(game.i18n.lang).trim();
    this.element.querySelectorAll("[data-cots-actor-row]").forEach(row => {
      const haystack = row.dataset.search ?? "";
      row.hidden = Boolean(needle) && !haystack.includes(needle);
    });
  }

  async #onPickerAction(event) {
    event.preventDefault();
    event.stopPropagation();

    const target = event.currentTarget;
    const action = target?.dataset?.cotsAction;
    if (action === "selectSpeaker") {
      const uuid = target.dataset.actorUuid;
      if (!uuid) return;
      await setGmSpeakerActorUuid(uuid);
      this.speakerController?.render();
      this.render({ force: true });
    } else if (action === "clearSpeaker") {
      await setGmSpeakerActorUuid("");
      this.speakerController?.render();
      this.render({ force: true });
    } else if (action === "previewSpeaker") {
      const actor = await resolveActorUuid(getGmSpeakerActorUuid());
      await this.speakerController?.previewActor(actor);
    } else if (action === "stopAll") {
      this.speakerController?.socketController?.emitStopAll();
    } else if (action === "stopExceptGm") {
      await this.speakerController?.stopAllExceptGm();
    } else if (action === "togglePresentationPaused") {
      await this.speakerController?.togglePresentationPaused();
      this.render({ force: true });
    } else if (action === "pinCurrentSpeaker") {
      await this.speakerController?.pinCurrentGmSpeaker();
      this.render({ force: true });
    } else if (action === "clearInactive") {
      this.speakerController?.clearInactiveParticipants();
      this.render({ force: true });
    } else if (action === "pinParticipant") {
      const key = target.dataset.participantKey;
      const actor = this.speakerController?.participants?.get(key)?.actor;
      this.speakerController?.socketController?.emitPinParticipant(actor);
      this.render({ force: true });
    } else if (action === "unpinParticipant") {
      const key = target.dataset.participantKey;
      this.speakerController?.socketController?.emitUnpinParticipant(key);
      this.render({ force: true });
    } else if (action === "refreshIndex") {
      this.actorIndex = null;
      this.render({ force: true });
    }
  }

  static async #selectSpeaker(event, target) {
    const uuid = target.dataset.actorUuid;
    if (!uuid) return;
    await setGmSpeakerActorUuid(uuid);
    this.speakerController?.render();
    this.render({ force: true });
  }

  static async #clearSpeaker() {
    await setGmSpeakerActorUuid("");
    this.speakerController?.render();
    this.render({ force: true });
  }

  static async #previewSpeaker() {
    const actor = await resolveActorUuid(getGmSpeakerActorUuid());
    await this.speakerController?.previewActor(actor);
  }

  static #stopAll() {
    this.speakerController?.socketController?.emitStopAll();
  }

  static #refreshIndex() {
    this.actorIndex = null;
    this.render({ force: true });
  }
}
