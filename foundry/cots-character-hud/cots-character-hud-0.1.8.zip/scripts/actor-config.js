import { FLAGS, HOOKS, MODULE_ID, TEMPLATES } from "./constants.js";
import { getActorConfig, sanitizeColor } from "./actor-data-adapter.js";
import { getSetting } from "./settings.js";
import { SETTINGS } from "./constants.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

function formObject(form, formData) {
  if (formData?.object) return formData.object;
  return Object.fromEntries(new FormData(form));
}

function canConfigureActor(actor) {
  if (!actor) return false;
  if (game.user.isGM) return true;
  return actor.isOwner === true;
}

function canConfigureCinematicFields() {
  return game.user.isGM || !getSetting(SETTINGS.GM_ONLY_CINEMATIC_CONFIG);
}

function clampPercent(value, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(100, Math.max(0, number));
}

export class ActorCinematicConfig extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: `${MODULE_ID}-actor-config`,
    classes: [MODULE_ID, `${MODULE_ID}-actor-config-app`],
    tag: "form",
    window: {
      title: `${MODULE_ID}.actorConfig.title`,
      icon: "fa-solid fa-theater-masks",
      resizable: false
    },
    position: {
      width: 430
    },
    form: {
      handler: this.#onSubmit,
      submitOnChange: false,
      closeOnSubmit: true
    },
    actions: {
      browsePortrait: this.#browsePortrait,
      previewPortrait: this.#previewPortrait,
      clearConfig: this.#clearConfig
    }
  };

  static PARTS = {
    form: {
      template: TEMPLATES.ACTOR_CONFIG
    }
  };

  constructor(actor, options = {}) {
    super(options);
    this.actor = actor;
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const config = getActorConfig(this.actor);
    return {
      ...context,
      actor: {
        uuid: this.actor.uuid,
        name: this.actor.name,
        img: this.actor.img || "icons/svg/mystery-man.svg"
      },
      config,
      previewPath: config.portraitPath || this.actor.img || "icons/svg/mystery-man.svg",
      canConfigure: canConfigureActor(this.actor),
      canConfigureCinematic: canConfigureCinematicFields(),
      canConfigureAccent: game.user.isGM || getSetting(SETTINGS.ALLOW_PLAYER_ACCENTS),
      sideChoices: [
        { value: "automatic", label: game.i18n.localize(`${MODULE_ID}.actorConfig.sideAutomatic`) },
        { value: "left", label: game.i18n.localize(`${MODULE_ID}.actorConfig.sideLeft`) },
        { value: "right", label: game.i18n.localize(`${MODULE_ID}.actorConfig.sideRight`) }
      ]
    };
  }

  static async #onSubmit(event, form, formData) {
    if (!canConfigureActor(this.actor)) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.noActorPermission`));
      return;
    }

    const data = formObject(form, formData);
    const current = getActorConfig(this.actor);
    const cinematicAllowed = canConfigureCinematicFields();
    const accentAllowed = game.user.isGM || getSetting(SETTINGS.ALLOW_PLAYER_ACCENTS);
    const sidePreference = ["automatic", "left", "right"].includes(data.sidePreference)
      ? data.sidePreference
      : "automatic";

    const next = {
      displayName: cinematicAllowed ? String(data.displayName ?? "").trim() : current.displayName,
      portraitPath: cinematicAllowed ? String(data.portraitPath ?? "").trim() : current.portraitPath,
      focusPortraitPath: cinematicAllowed ? String(data.focusPortraitPath ?? "").trim() : current.focusPortraitPath,
      carouselPortraitPath: cinematicAllowed ? String(data.carouselPortraitPath ?? "").trim() : current.carouselPortraitPath,
      carouselName: cinematicAllowed ? String(data.carouselName ?? "").trim().slice(0, 32) : current.carouselName,
      focalX: cinematicAllowed ? clampPercent(data.focalX, current.focalX) : current.focalX,
      focalY: cinematicAllowed ? clampPercent(data.focalY, current.focalY) : current.focalY,
      accentColor: accentAllowed ? sanitizeColor(data.accentColor, current.accentColor) : current.accentColor,
      sidePreference: cinematicAllowed ? sidePreference : current.sidePreference,
      flipPortrait: cinematicAllowed ? Boolean(data.flipPortrait) : current.flipPortrait
    };

    await this.actor.setFlag(MODULE_ID, FLAGS.ACTOR_CONFIG, next);
    Hooks.callAll(HOOKS.CONFIG_CHANGED, "actorConfig", this.actor);
  }

  static #browsePortrait(event, target) {
    event.preventDefault();
    const input = this.element.querySelector('input[name="portraitPath"]');
    if (!input) return;
    if (!globalThis.FilePicker) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.noFilePicker`));
      return;
    }
    const picker = new FilePicker({
      type: "image",
      current: input.value || this.actor.img || "",
      callback: path => {
        input.value = path;
        this.#setPreview(path);
      }
    });
    picker.browse(input.value || "");
  }

  static #previewPortrait(event) {
    event.preventDefault();
    const input = this.element.querySelector('input[name="portraitPath"]');
    this.#setPreview(input?.value || this.actor.img || "icons/svg/mystery-man.svg");
  }

  static async #clearConfig(event) {
    event.preventDefault();
    if (!canConfigureActor(this.actor)) return;
    await this.actor.unsetFlag(MODULE_ID, FLAGS.ACTOR_CONFIG);
    Hooks.callAll(HOOKS.CONFIG_CHANGED, "actorConfig", this.actor);
    this.render({ force: true });
  }

  #setPreview(path) {
    const preview = this.element.querySelector("[data-cots-portrait-preview]");
    if (preview) preview.src = path || this.actor.img || "icons/svg/mystery-man.svg";
  }
}

export function registerActorConfigHooks() {
  Hooks.on("getHeaderControlsApplicationV2", (application, controls) => {
    const actor = application.document?.documentName === "Actor" ? application.document : application.actor;
    if (!actor || !canConfigureActor(actor)) return;
    if (!canConfigureCinematicFields() && !getSetting(SETTINGS.ALLOW_PLAYER_ACCENTS)) return;

    controls.push({
      action: `${MODULE_ID}.actorConfig`,
      label: `${MODULE_ID}.actorConfig.headerButton`,
      icon: "fa-solid fa-theater-masks",
      ownership: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER,
      onClick: () => new ActorCinematicConfig(actor).render({ force: true })
    });
  });
}
