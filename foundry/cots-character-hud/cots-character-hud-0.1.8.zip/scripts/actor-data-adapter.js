import { FLAGS, MODULE_ID, ownerPermissionLevel } from "./constants.js";

const DEFAULT_ACCENT = "#c79b47";
const MAJOR_CONDITION_ORDER = [
  "dead",
  "defeated",
  "unconscious",
  "incapacitated",
  "paralyzed",
  "stunned",
  "restrained",
  "poisoned",
  "frightened",
  "charmed",
  "prone"
];

function getProperty(object, path) {
  if (!object || !path) return undefined;
  const foundryGet = globalThis.foundry?.utils?.getProperty;
  if (foundryGet) return foundryGet(object, path);
  return path.split(".").reduce((value, part) => value?.[part], object);
}

function firstDefined(...values) {
  return values.find(value => value !== undefined && value !== null && value !== "");
}

function titleCase(value) {
  return String(value ?? "")
    .replace(/[-_]/g, " ")
    .replace(/\b\w/g, character => character.toUpperCase());
}

function numberOrNull(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") {
    const match = value.match(/-?\d+(\.\d+)?/);
    if (match) return Number(match[0]);
  }
  return null;
}

function normalizePath(path) {
  return typeof path === "string" && path.trim() ? path.trim() : "";
}

function clampPercent(value, fallback = 50) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(100, Math.max(0, number));
}

function shortText(value, max = 32) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

export function sanitizeColor(value, fallback = DEFAULT_ACCENT) {
  if (typeof value !== "string") return fallback;
  const color = value.trim();
  return /^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/.test(color) ? color : fallback;
}

function documentName(document) {
  return document?.documentName ?? document?.constructor?.documentName ?? "";
}

function isTokenDocument(document) {
  const name = documentName(document);
  return name === "Token" || name === "TokenDocument" || Boolean(document?.actor && String(document?.uuid ?? "").includes(".Token."));
}

function findTokenPlaceableForDocument(tokenDocument) {
  if (!tokenDocument || !globalThis.canvas?.ready) return null;
  const sceneId = tokenDocument.parent?.id ?? tokenDocument.parent?.uuid?.split(".")[1] ?? "";
  if (sceneId && canvas.scene?.id !== sceneId) return null;
  return (canvas.tokens?.placeables ?? []).find(token => token.document?.uuid === tokenDocument.uuid || token.document?.id === tokenDocument.id) ?? null;
}

export function getActorConfig(actor) {
  const raw = actor?.getFlag?.(MODULE_ID, FLAGS.ACTOR_CONFIG) ?? {};
  const sidePreference = ["automatic", "left", "right"].includes(raw.sidePreference) ? raw.sidePreference : "automatic";
  return {
    displayName: typeof raw.displayName === "string" ? raw.displayName.trim() : "",
    portraitPath: normalizePath(raw.portraitPath),
    focusPortraitPath: normalizePath(raw.focusPortraitPath),
    carouselPortraitPath: normalizePath(raw.carouselPortraitPath),
    carouselName: shortText(raw.carouselName),
    focalX: clampPercent(raw.focalX, 50),
    focalY: clampPercent(raw.focalY, 35),
    accentColor: sanitizeColor(raw.accentColor, DEFAULT_ACCENT),
    sidePreference,
    flipPortrait: raw.flipPortrait === true
  };
}

export function buildActorSnapshot(actor) {
  if (!actor) return null;
  const config = getActorConfig(actor);
  return {
    actorUuid: actor.uuid,
    name: config.displayName || actor.name || "",
    img: config.portraitPath || config.focusPortraitPath || actor.img || "icons/svg/mystery-man.svg",
    focusImg: config.focusPortraitPath || config.portraitPath || actor.img || "icons/svg/mystery-man.svg",
    carouselImg: config.carouselPortraitPath || config.portraitPath || config.focusPortraitPath || actor.img || "icons/svg/mystery-man.svg",
    carouselName: config.carouselName,
    focalX: config.focalX,
    focalY: config.focalY,
    accentColor: config.accentColor,
    sidePreference: config.sidePreference,
    flipPortrait: config.flipPortrait
  };
}

export function sanitizeActorSnapshot(snapshot) {
  if (!snapshot || typeof snapshot !== "object") return null;
  const sidePreference = ["automatic", "left", "right"].includes(snapshot.sidePreference)
    ? snapshot.sidePreference
    : "automatic";
  return {
    actorUuid: typeof snapshot.actorUuid === "string" ? snapshot.actorUuid : "",
    name: typeof snapshot.name === "string" ? snapshot.name.slice(0, 120) : "",
    img: normalizePath(snapshot.img) || "icons/svg/mystery-man.svg",
    focusImg: normalizePath(snapshot.focusImg) || normalizePath(snapshot.img) || "icons/svg/mystery-man.svg",
    carouselImg: normalizePath(snapshot.carouselImg) || normalizePath(snapshot.img) || "icons/svg/mystery-man.svg",
    carouselName: shortText(snapshot.carouselName),
    focalX: clampPercent(snapshot.focalX, 50),
    focalY: clampPercent(snapshot.focalY, 35),
    accentColor: sanitizeColor(snapshot.accentColor, DEFAULT_ACCENT),
    sidePreference,
    flipPortrait: snapshot.flipPortrait === true
  };
}

export function canUserSelectActor(actor, user = game.user) {
  if (!actor || !user) return false;
  if (user.isGM) return true;
  return actor.testUserPermission?.(user, ownerPermissionLevel()) === true;
}

export async function resolveActorUuid(uuid) {
  return (await resolveActorReferenceUuid(uuid))?.actor ?? null;
}

export async function resolveActorReferenceUuid(uuid) {
  if (typeof uuid !== "string" || !uuid.trim()) return null;
  try {
    if (globalThis.fromUuid) {
      const document = await fromUuid(uuid);
      if (documentName(document) === "Actor") return { uuid: document.uuid, actor: document, token: null, tokenDocument: null };
      if (isTokenDocument(document) && document.actor) {
        return {
          uuid: document.uuid ?? uuid,
          actor: document.actor,
          token: findTokenPlaceableForDocument(document),
          tokenDocument: document
        };
      }
    }
    if (uuid.startsWith("Actor.")) {
      const actor = game.actors.get(uuid.split(".")[1]) ?? null;
      return actor ? { uuid: actor.uuid, actor, token: null, tokenDocument: null } : null;
    }
  } catch (error) {
    console.warn(`${MODULE_ID} | Could not resolve actor reference UUID ${uuid}`, error);
  }
  return null;
}

export function getSelectableActors(user = game.user) {
  return game.actors
    .filter(actor => canUserSelectActor(actor, user))
    .sort((a, b) => a.name.localeCompare(b.name, game.i18n.lang))
    .map(actor => ({
      id: actor.id,
      uuid: actor.uuid,
      name: actor.name,
      img: actor.img || "icons/svg/mystery-man.svg",
      type: actor.type
    }));
}

function getMovementLabel(actor) {
  const movement = getProperty(actor, "system.attributes.movement");
  const legacySpeed = firstDefined(
    getProperty(actor, "system.attributes.speed.value"),
    getProperty(actor, "system.attributes.speed")
  );
  const units = firstDefined(
    movement?.units,
    getProperty(actor, "system.attributes.speed.units"),
    game.i18n.localize("DND5E.DistFt") === "DND5E.DistFt" ? "ft" : game.i18n.localize("DND5E.DistFt")
  );

  if (movement && typeof movement === "object") {
    const parts = ["walk", "fly", "swim", "climb", "burrow"]
      .map(type => {
        const value = numberOrNull(movement[type]);
        return value && value > 0 ? `${titleCase(type)} ${value} ${units}` : null;
      })
      .filter(Boolean);
    if (parts.length) return parts.join(", ");
  }

  if (legacySpeed && typeof legacySpeed === "object") {
    const value = firstDefined(legacySpeed.value, legacySpeed.walk);
    return value ? String(value) : "";
  }
  return legacySpeed ? String(legacySpeed) : "";
}

function getSpellSlots(actor) {
  const spells = getProperty(actor, "system.spells") ?? {};
  if (!spells || typeof spells !== "object") return [];

  return Object.entries(spells)
    .map(([key, slot]) => {
      if (!slot || typeof slot !== "object") return null;
      const value = numberOrNull(slot.value) ?? 0;
      const max = numberOrNull(firstDefined(slot.max, slot.override)) ?? 0;
      if (max <= 0 && value <= 0) return null;
      const level = key.match(/\d+/)?.[0];
      const label = key === "pact" ? "Pact" : level ? `L${level}` : titleCase(key);
      return { key, label, value, max };
    })
    .filter(Boolean)
    .sort((a, b) => {
      if (a.key === "pact") return 1;
      if (b.key === "pact") return -1;
      return a.key.localeCompare(b.key, game.i18n.lang, { numeric: true });
    });
}

function getResources(actor) {
  const paths = [
    ["primary", "system.resources.primary"],
    ["secondary", "system.resources.secondary"],
    ["tertiary", "system.resources.tertiary"],
    ["legendary", "system.resources.legact"],
    ["legendaryResistances", "system.resources.legres"],
    ["hitDice", "system.attributes.hd"],
    ["actions", "system.attributes.actions"]
  ];

  return paths
    .map(([key, path]) => {
      const resource = getProperty(actor, path);
      if (!resource || typeof resource !== "object") return null;
      const value = numberOrNull(resource.value) ?? 0;
      const max = numberOrNull(resource.max) ?? 0;
      const label = resource.label || titleCase(key);
      if (max <= 0 && value <= 0) return null;
      return { key, label, value, max };
    })
    .filter(Boolean);
}

function collectStatuses(actor, tokenDocument = null) {
  const statuses = new Set();
  for (const effect of actor?.effects ?? []) {
    if (effect.disabled) continue;
    if (effect.statuses instanceof Set) {
      for (const status of effect.statuses) statuses.add(String(status).toLowerCase());
    }
    const statusId = effect.statuses?.values?.().next?.().value ?? effect.statusId ?? effect.getFlag?.("core", "statusId");
    if (statusId) statuses.add(String(statusId).toLowerCase());
    if (effect.name) statuses.add(String(effect.name).toLowerCase());
  }

  const token = tokenDocument ? null : findActiveToken(actor);
  const tokenStatuses = tokenDocument?.statuses ?? token?.document?.statuses;
  if (tokenStatuses instanceof Set) {
    for (const status of tokenStatuses) statuses.add(String(status).toLowerCase());
  }

  const special = globalThis.CONFIG?.specialStatusEffects ?? {};
  for (const value of Object.values(special)) {
    if (value && statuses.has(String(value).toLowerCase())) statuses.add(String(value).toLowerCase());
  }
  return statuses;
}

function getMajorStatus(actor, hp, tokenDocument = null) {
  const statuses = collectStatuses(actor, tokenDocument);
  for (const condition of MAJOR_CONDITION_ORDER) {
    if (statuses.has(condition)) return { label: titleCase(condition), cssClass: condition };
  }
  if (Number.isFinite(hp.value) && hp.value <= 0 && Number.isFinite(hp.max) && hp.max > 0) {
    return { label: "Unconscious", cssClass: "unconscious" };
  }
  return null;
}

function getActorLevel(actor) {
  const direct = numberOrNull(getProperty(actor, "system.details.level"));
  if (direct && direct > 0) return direct;

  const classes = getProperty(actor, "system.classes");
  if (classes && typeof classes === "object") {
    const total = Object.values(classes).reduce((sum, item) => {
      const levels = numberOrNull(item?.system?.levels ?? item?.levels);
      return levels && levels > 0 ? sum + levels : sum;
    }, 0);
    if (total > 0) return total;
  }
  return "";
}

export function getActorStats(actor, reference = {}) {
  const tokenDocument = reference.tokenDocument ?? reference.token?.document ?? null;
  const config = getActorConfig(actor);
  const hpValue = numberOrNull(getProperty(actor, "system.attributes.hp.value")) ?? 0;
  const hpMax = numberOrNull(getProperty(actor, "system.attributes.hp.max")) ?? 0;
  const hpTemp = numberOrNull(getProperty(actor, "system.attributes.hp.temp")) ?? 0;
  const hpTempMax = numberOrNull(getProperty(actor, "system.attributes.hp.tempmax")) ?? 0;
  const hp = {
    value: hpValue,
    max: hpMax,
    temp: hpTemp,
    tempmax: hpTempMax,
    maxSafe: Math.max(1, hpMax),
    pct: hpMax > 0 ? Math.max(0, Math.min(100, Math.round((hpValue / hpMax) * 100))) : 0
  };

  const spellSlots = getSpellSlots(actor);
  const resources = spellSlots.length ? [] : getResources(actor);
  const state = getMajorStatus(actor, hp, tokenDocument);
  const tokenImg = tokenDocument?.texture?.src || reference.token?.document?.texture?.src || "";

  return {
    uuid: reference.uuid || actor.uuid,
    actorUuid: actor.uuid,
    id: actor.id,
    type: actor.type,
    name: tokenDocument?.name || config.displayName || actor.name || "",
    baseName: actor.name || "",
    img: config.portraitPath || config.focusPortraitPath || tokenImg || actor.img || "icons/svg/mystery-man.svg",
    focusImg: config.focusPortraitPath || config.portraitPath || actor.img || "icons/svg/mystery-man.svg",
    carouselImg: config.carouselPortraitPath || config.portraitPath || config.focusPortraitPath || actor.img || "icons/svg/mystery-man.svg",
    carouselName: config.carouselName,
    focalX: config.focalX,
    focalY: config.focalY,
    portraitPosition: `${config.focalX}% ${config.focalY}%`,
    actorImg: actor.img || "icons/svg/mystery-man.svg",
    accentColor: config.accentColor,
    sidePreference: config.sidePreference,
    flipPortrait: config.flipPortrait,
    hp,
    ac: firstDefined(
      numberOrNull(getProperty(actor, "system.attributes.ac.value")),
      numberOrNull(getProperty(actor, "system.attributes.ac.flat")),
      numberOrNull(getProperty(actor, "system.attributes.ac.base")),
      ""
    ),
    level: getActorLevel(actor),
    movement: getMovementLabel(actor),
    spellSlots,
    resources,
    state,
    hasSpellSlots: spellSlots.length > 0,
    hasResources: resources.length > 0
  };
}

export function findActiveToken(actor, referenceUuid = "") {
  if (!actor || !globalThis.canvas?.ready) return null;
  const tokens = canvas.tokens?.placeables ?? [];
  if (referenceUuid) {
    const direct = tokens.find(token => token.document?.uuid === referenceUuid || token.document?.id === referenceUuid);
    if (direct) return direct;
  }
  return tokens.find(token => {
    const tokenActor = token.actor;
    return tokenActor?.uuid === actor.uuid || tokenActor?.id === actor.id || token.document?.actorId === actor.id;
  }) ?? null;
}

export function canUserControlToken(token, user = game.user) {
  if (!token) return false;
  return token.can?.(user, "control") ?? token.document?.testUserPermission?.(user, ownerPermissionLevel()) ?? token.isOwner ?? canUserSelectActor(token.actor, user);
}

export function selectActorToken(actor, { pan = false, referenceUuid = "" } = {}) {
  const token = findActiveToken(actor, referenceUuid);
  if (!token) {
    ui.notifications?.warn(game.i18n.format(`${MODULE_ID}.notifications.noActiveToken`, { name: actor?.name ?? "" }));
    return false;
  }

  const canControl = canUserControlToken(token);
  if (!canControl) {
    ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.cannotControlToken`));
    return false;
  }

  token.control({ releaseOthers: true, pan });
  if (pan && token.center && canvas.animatePan) {
    canvas.animatePan({ x: token.center.x, y: token.center.y, duration: 350 });
  }
  return true;
}

export function openActorSheet(actor) {
  if (!actor?.sheet) return false;
  actor.sheet.render({ force: true });
  return true;
}

export function getOwnedSceneTokenCandidates(excludedUuids = new Set()) {
  if (!globalThis.canvas?.ready) return [];
  const seen = new Set(excludedUuids);
  const candidates = [];
  for (const token of canvas.tokens?.placeables ?? []) {
    const actor = token.actor;
    const tokenUuid = token.document?.uuid;
    if (!actor || !tokenUuid || seen.has(tokenUuid) || seen.has(actor.uuid) || !canUserControlToken(token)) continue;
    seen.add(tokenUuid);
    candidates.push({
      uuid: tokenUuid,
      actorUuid: actor.uuid,
      name: token.name || actor.name,
      img: token.document?.texture?.src || actor.img || "icons/svg/mystery-man.svg",
      actorName: actor.name,
      tokenName: token.name,
      temporary: actor.isToken === true || !game.actors.get(actor.id)
    });
  }
  return candidates.sort((a, b) => a.name.localeCompare(b.name, game.i18n.lang));
}
