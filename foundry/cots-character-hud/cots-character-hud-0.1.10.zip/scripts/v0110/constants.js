export const MODULE_ID = "cots-character-hud";
export const MODULE_TITLE = "COTS Character HUD";
export const SOCKET_EVENT = `module.${MODULE_ID}`;

export const FLAGS = Object.freeze({
  USER_CONFIG: "userConfig",
  ACTOR_CONFIG: "actorConfig"
});

export const SETTINGS = Object.freeze({
  ENABLE_PLAYER_HUD: "enablePlayerHud",
  ENABLE_SPEAKER_OVERLAY: "enableSpeakerOverlay",
  MAX_SPEAKERS: "maxSpeakers",
  DEFAULT_LINGER: "defaultLingerDuration",
  ALLOW_PLAYER_ACCENTS: "allowPlayerAccentColors",
  GM_ONLY_CINEMATIC_CONFIG: "gmOnlyCinematicConfig",
  ALLOW_CLIENT_LINGER_OVERRIDE: "allowClientLingerOverride",
  PRESENT_TEXT_CHAT: "presentTextChat",
  MAX_CONVERSATION_PARTICIPANTS: "maxConversationParticipants",
  ALLOW_PLAYER_PINNING: "allowPlayerPinning",
  PINNED_SURVIVE_SCENE_CHANGE: "pinnedSurviveSceneChange",
  SPEAKER_PRESENTATIONS_PAUSED: "speakerPresentationsPaused",
  HUD_ENABLED: "hudEnabled",
  HUD_POSITION: "hudPosition",
  HUD_WIDTH: "hudWidth",
  HUD_HEIGHT: "hudHeight",
  HUD_SCALE: "hudScale",
  HUD_BACKGROUND_COLOR: "hudBackgroundColor",
  HUD_GRADIENT_START: "hudGradientStart",
  HUD_GRADIENT_END: "hudGradientEnd",
  HUD_BORDER_COLOR: "hudBorderColor",
  HUD_TEXT_COLOR: "hudTextColor",
  HUD_PANEL_OPACITY: "hudPanelOpacity",
  COMPANION_TRAY_COLLAPSED: "companionTrayCollapsed",
  SPEAKER_OVERLAY_ENABLED: "speakerOverlayEnabled",
  SPEAKER_OVERLAY_SCALE: "speakerOverlayScale",
  SHOW_PARTICIPANT_CAROUSEL: "showParticipantCarousel",
  PARTICIPANT_CAROUSEL_SCALE: "participantCarouselScale",
  COMPACT_PARTICIPANT_CAROUSEL: "compactParticipantCarousel",
  SHOW_TOKEN_SPEECH_BUBBLES: "showTokenSpeechBubbles",
  SPEAKER_LINGER_OVERRIDE: "speakerLingerOverride",
  GM_SPEAKER_ACTOR_UUID: "gmSpeakerActorUuid",
  GM_DOCK_OFFSET: "gmDockOffset",
  REDUCED_ANIMATION: "reducedAnimation",
  MANUAL_PRESENTATION_ENABLED: "manualPresentationEnabled",
  VOICE_ACTIVITY_ENABLED: "voiceActivityEnabled",
  VOICE_INPUT_DEVICE_ID: "voiceInputDeviceId",
  VOICE_ACTIVITY_THRESHOLD: "voiceActivityThreshold",
  VOICE_ACTIVITY_RELEASE_DELAY: "voiceActivityReleaseDelay",
  OVERLAY_LAYOUT: "overlayLayout",
  OVERLAY_BACKGROUND_COLOR: "overlayBackgroundColor",
  OVERLAY_GRADIENT_START: "overlayGradientStart",
  OVERLAY_GRADIENT_END: "overlayGradientEnd",
  OVERLAY_BORDER_COLOR: "overlayBorderColor",
  OVERLAY_PANEL_OPACITY: "overlayPanelOpacity",
  OVERLAY_PORTRAIT_OPACITY: "overlayPortraitOpacity"
});

export const KEYBINDINGS = Object.freeze({
  HOLD_MAIN: "holdMainSpeaker",
  TOGGLE_MAIN: "toggleMainSpeaker",
  HOLD_GM: "holdGmSpeaker"
});

export const SOCKET_TYPES = Object.freeze({
  START: "speaker:start",
  STOP: "speaker:stop",
  STOP_ALL: "speaker:stop-all",
  STOP_EXCEPT_GM: "speaker:stop-except-gm",
  SET_PAUSED: "speaker:set-paused",
  PIN_PARTICIPANT: "speaker:pin-participant",
  UNPIN_PARTICIPANT: "speaker:unpin-participant",
  CLEAR_INACTIVE: "speaker:clear-inactive"
});

export const TEMPLATES = Object.freeze({
  HUD: `modules/${MODULE_ID}/templates/v0110/hud.html`,
  HUD_CONFIG: `modules/${MODULE_ID}/templates/v0110/hud-config.html`,
  SPEAKER_OVERLAY: `modules/${MODULE_ID}/templates/v0110/speaker-overlay.html`,
  GM_SPEAKER_PICKER: `modules/${MODULE_ID}/templates/v0110/gm-speaker-picker.html`,
  ACTOR_CONFIG: `modules/${MODULE_ID}/templates/v0110/actor-config.html`,
  OVERLAY_APPEARANCE_CONFIG: `modules/${MODULE_ID}/templates/v0110/appearance-config.html`,
  VOICE_INPUT_CONFIG: `modules/${MODULE_ID}/templates/v0110/voice-input-config.html`
});

export const HOOKS = Object.freeze({
  CONFIG_CHANGED: `${MODULE_ID}.configChanged`,
  USER_CONFIG_CHANGED: `${MODULE_ID}.userConfigChanged`,
  SPEAKERS_CHANGED: `${MODULE_ID}.speakersChanged`
});

export function localize(key) {
  return game.i18n.localize(`${MODULE_ID}.${key}`);
}

export function format(key, data = {}) {
  return game.i18n.format(`${MODULE_ID}.${key}`, data);
}

export function ownerPermissionLevel() {
  return globalThis.CONST?.DOCUMENT_OWNERSHIP_LEVELS?.OWNER ?? 3;
}

export function randomId() {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}
