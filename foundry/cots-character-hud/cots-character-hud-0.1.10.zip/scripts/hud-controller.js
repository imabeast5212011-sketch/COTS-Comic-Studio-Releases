import { ActorCinematicConfig } from "./actor-config.js";
import { HOOKS, MODULE_ID, SETTINGS, TEMPLATES } from "./constants.js";
import {
  canUserControlToken,
  canUserSelectActor,
  getActorStats,
  getOwnedSceneTokenCandidates,
  getSelectableActors,
  openActorSheet,
  resolveActorReferenceUuid,
  resolveActorUuid,
  selectActorToken
} from "./actor-data-adapter.js";
import { getCurrentUserConfig, addCompanionActor, removeCompanionActor, updateCurrentUserConfig } from "./user-config.js";
import {
  getConstrainedHudHeight,
  getConstrainedHudWidth,
  getHudAppearance,
  getHudHeight,
  getHudPosition,
  getHudScale,
  getHudWidth,
  getSetting,
  hexToRgb,
  setHudPosition,
  setHudHeight,
  setHudWidth,
  setSetting,
  usesReducedAnimation
} from "./settings.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

function formObject(form, formData) {
  if (formData?.object) return formData.object;
  return Object.fromEntries(new FormData(form));
}

export class HudController {
  constructor(speakerController) {
    this.speakerController = speakerController;
    this.element = null;
    this.refreshTimer = null;
    this.dragState = null;
    this.resizeState = null;
    this._boundRefresh = this.refresh.bind(this);
    this._boundActorUpdate = this._onActorUpdate.bind(this);
    this._boundActorDelete = this._onActorDelete.bind(this);
  }

  initialize() {
    Hooks.on(HOOKS.CONFIG_CHANGED, this._boundRefresh);
    Hooks.on(HOOKS.USER_CONFIG_CHANGED, this._boundRefresh);
    Hooks.on("updateActor", this._boundActorUpdate);
    Hooks.on("deleteActor", this._boundActorDelete);
    Hooks.on("canvasReady", this._boundRefresh);
    Hooks.on("canvasTearDown", this._boundRefresh);
    window.addEventListener("resize", this._boundRefresh);
    this.render();
  }

  destroy() {
    Hooks.off(HOOKS.CONFIG_CHANGED, this._boundRefresh);
    Hooks.off(HOOKS.USER_CONFIG_CHANGED, this._boundRefresh);
    Hooks.off("updateActor", this._boundActorUpdate);
    Hooks.off("deleteActor", this._boundActorDelete);
    Hooks.off("canvasReady", this._boundRefresh);
    Hooks.off("canvasTearDown", this._boundRefresh);
    window.removeEventListener("resize", this._boundRefresh);
    this.remove();
  }

  refresh() {
    window.clearTimeout(this.refreshTimer);
    this.refreshTimer = window.setTimeout(() => this.render(), 60);
  }

  async render() {
    if (!this.#hudEnabled()) {
      this.remove();
      return;
    }

    const config = getCurrentUserConfig();
    const mainActor = await resolveActorUuid(config.mainActorUuid);
    const companionReferences = (await Promise.all(config.companionActorUuids.map(uuid => resolveActorReferenceUuid(uuid))))
      .filter(reference => reference?.actor && (reference.token ? canUserControlToken(reference.token) : canUserSelectActor(reference.actor)));

    const excluded = new Set([config.mainActorUuid, ...config.companionActorUuids].filter(Boolean));
    const context = {
      moduleId: MODULE_ID,
      expanded: config.hudExpanded,
      trayCollapsed: config.companionTrayCollapsed,
      reducedMotion: usesReducedAnimation(),
      main: mainActor ? getActorStats(mainActor) : null,
      companions: companionReferences.map(reference => getActorStats(reference.actor, reference)),
      summonCandidates: getOwnedSceneTokenCandidates(excluded),
      hasCompanions: companionReferences.length > 0,
      hudHeight: getHudHeight(),
      hudScale: getHudScale(),
      hudWidth: getHudWidth(),
      manualPresentationEnabled: getSetting(SETTINGS.MANUAL_PRESENTATION_ENABLED),
      talkToggleLabel: game.i18n.localize(`${MODULE_ID}.hud.${getSetting(SETTINGS.MANUAL_PRESENTATION_ENABLED) ? "disableTalk" : "enableTalk"}`),
      talkToggleIcon: getSetting(SETTINGS.MANUAL_PRESENTATION_ENABLED) ? "fa-ban" : "fa-comment-dots",
      chatPresentationEnabled: config.chatPresentationEnabled,
      chatToggleLabel: game.i18n.localize(`${MODULE_ID}.hud.${config.chatPresentationEnabled ? "disableChat" : "enableChat"}`),
      chatToggleIcon: config.chatPresentationEnabled ? "fa-comment-slash" : "fa-comment-dots"
    };

    const html = await foundry.applications.handlebars.renderTemplate(TEMPLATES.HUD, context);
    const next = document.createRange().createContextualFragment(html).firstElementChild;
    if (!next) return;

    if (this.element) this.element.replaceWith(next);
    else document.body.appendChild(next);
    this.element = next;
    this.#applyPosition();
    this.#activateListeners();
  }

  remove() {
    window.clearTimeout(this.refreshTimer);
    this.element?.remove();
    this.element = null;
  }

  async openConfig() {
    new HudConfigApp(this).render({ force: true });
  }

  async _onActorUpdate(actor) {
    const config = getCurrentUserConfig();
    if (actor.uuid === config.mainActorUuid || config.companionActorUuids.includes(actor.uuid)) this.refresh();
  }

  async _onActorDelete(actor) {
    const config = getCurrentUserConfig();
    if (actor.uuid === config.mainActorUuid) await updateCurrentUserConfig({ mainActorUuid: "" });
    if (config.companionActorUuids.includes(actor.uuid)) await removeCompanionActor(actor.uuid);
    this.refresh();
  }

  #hudEnabled() {
    return Boolean(getSetting(SETTINGS.ENABLE_PLAYER_HUD)) && Boolean(getSetting(SETTINGS.HUD_ENABLED)) && game.view === "game";
  }

  #applyPosition() {
    const position = getHudPosition();
    this.element.style.left = `${position.left}px`;
    this.element.style.top = `${position.top}px`;
    this.element.style.setProperty("--cots-hud-scale", String(getHudScale()));
    this.element.style.setProperty("--cots-hud-height", `${getConstrainedHudHeight(getHudHeight(), { top: position.top })}px`);
    this.element.style.setProperty("--cots-hud-width", `${getHudWidth()}px`);
    this.#applyHudAppearance();
    this.element.classList.toggle("cots-reduced-motion", usesReducedAnimation());
  }

  #applyHudAppearance() {
    const appearance = getHudAppearance();
    const background = hexToRgb(appearance.backgroundColor);
    this.element.style.setProperty("--cots-hud-panel-bg", `rgba(${background.r}, ${background.g}, ${background.b}, ${appearance.panelOpacity})`);
    this.element.style.setProperty("--cots-hud-gradient-start", appearance.gradientStart);
    this.element.style.setProperty("--cots-hud-gradient-end", appearance.gradientEnd);
    this.element.style.setProperty("--cots-hud-border-color", appearance.borderColor);
    this.element.style.setProperty("--cots-hud-text-color", appearance.textColor);
  }

  #activateListeners() {
    this.element.querySelectorAll("[data-action]").forEach(control => {
      control.addEventListener("click", event => this.#onAction(event));
      control.addEventListener("dblclick", event => this.#onDoubleClick(event));
    });
    const dragHandle = this.element.querySelector("[data-cots-drag-handle]");
    dragHandle?.addEventListener("pointerdown", event => this.#startDrag(event));
    this.element.querySelector("[data-cots-hud-resize-handle]")?.addEventListener("pointerdown", event => this.#startResize(event));
  }

  async #onAction(event) {
    const target = event.currentTarget;
    const action = target.dataset.action;
    if (action === "actor-primary") {
      this.#handleActorClick(event, target.dataset.actorUuid);
    } else if (action === "open-config") {
      this.openConfig();
    } else if (action === "toggle-hud") {
      const config = getCurrentUserConfig();
      await updateCurrentUserConfig({ hudExpanded: !config.hudExpanded });
    } else if (action === "toggle-tray") {
      const config = getCurrentUserConfig();
      await updateCurrentUserConfig({ companionTrayCollapsed: !config.companionTrayCollapsed });
    } else if (action === "remove-companion") {
      event.stopPropagation();
      await removeCompanionActor(target.dataset.actorUuid);
    } else if (action === "speaker-main") {
      this.speakerController.toggleMainPresentation();
    } else if (action === "toggle-talk") {
      await setSetting(SETTINGS.MANUAL_PRESENTATION_ENABLED, !getSetting(SETTINGS.MANUAL_PRESENTATION_ENABLED));
    } else if (action === "toggle-chat-presentation") {
      const config = getCurrentUserConfig();
      await updateCurrentUserConfig({ chatPresentationEnabled: !config.chatPresentationEnabled });
    } else if (action === "actor-config") {
      const actor = await resolveActorUuid(target.dataset.actorUuid);
      if (actor) new ActorCinematicConfig(actor).render({ force: true });
    }
  }

  async #onDoubleClick(event) {
    const target = event.currentTarget;
    if (target.dataset.action !== "actor-primary") return;
    event.preventDefault();
    event.stopPropagation();
    const actor = await resolveActorUuid(target.dataset.actorUuid);
    if (actor) openActorSheet(actor);
  }

  async #handleActorClick(event, uuid) {
    if (event.detail > 1) return;
    const actor = await resolveActorUuid(uuid);
    if (!actor) return;
    window.setTimeout(() => {
      if (event.detail > 1) return;
      selectActorToken(actor, { pan: event.shiftKey, referenceUuid: uuid });
    }, 180);
  }

  #startDrag(event) {
    if (event.button !== 0 || event.target.closest("button, input, select, textarea, a")) return;
    event.preventDefault();
    const rect = this.element.getBoundingClientRect();
    this.dragState = {
      pointerId: event.pointerId,
      offsetX: event.clientX - rect.left,
      offsetY: event.clientY - rect.top
    };
    this.element.setPointerCapture?.(event.pointerId);
    this.element.classList.add("is-dragging");
    const move = moveEvent => this.#continueDrag(moveEvent);
    const up = upEvent => {
      this.#endDrag(upEvent);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  #continueDrag(event) {
    if (!this.dragState || event.pointerId !== this.dragState.pointerId) return;
    const rect = this.element.getBoundingClientRect();
    const maxLeft = Math.max(0, window.innerWidth - Math.min(rect.width, window.innerWidth));
    const maxTop = Math.max(0, window.innerHeight - Math.min(rect.height, window.innerHeight));
    const left = Math.max(0, Math.min(maxLeft, event.clientX - this.dragState.offsetX));
    const top = Math.max(0, Math.min(maxTop, event.clientY - this.dragState.offsetY));
    this.element.style.left = `${left}px`;
    this.element.style.top = `${top}px`;
  }

  #endDrag(event) {
    if (!this.dragState || event.pointerId !== this.dragState.pointerId) return;
    this.element.releasePointerCapture?.(event.pointerId);
    this.element.classList.remove("is-dragging");
    const rect = this.element.getBoundingClientRect();
    this.dragState = null;
    setHudPosition({ left: rect.left, top: rect.top });
  }

  #startResize(event) {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    const scale = getHudScale();
    const rect = this.element.getBoundingClientRect();
    this.resizeState = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      scale,
      startWidth: getHudWidth(),
      startHeight: getConstrainedHudHeight(getHudHeight(), { top: rect.top }),
      top: rect.top,
      nextWidth: getHudWidth(),
      nextHeight: getConstrainedHudHeight(getHudHeight(), { top: rect.top })
    };
    event.currentTarget.setPointerCapture?.(event.pointerId);
    this.element.classList.add("is-resizing");
    const move = moveEvent => this.#continueResize(moveEvent);
    const up = upEvent => {
      this.#endResize(upEvent);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  #continueResize(event) {
    if (!this.resizeState || event.pointerId !== this.resizeState.pointerId) return;
    const width = this.resizeState.startWidth + ((event.clientX - this.resizeState.startX) / this.resizeState.scale);
    const height = this.resizeState.startHeight + ((event.clientY - this.resizeState.startY) / this.resizeState.scale);
    const nextWidth = getConstrainedHudWidth(width);
    const nextHeight = getConstrainedHudHeight(height, { top: this.resizeState.top });
    this.resizeState.nextWidth = nextWidth;
    this.resizeState.nextHeight = nextHeight;
    this.element.style.setProperty("--cots-hud-width", `${nextWidth}px`);
    this.element.style.setProperty("--cots-hud-height", `${nextHeight}px`);
  }

  #endResize(event) {
    if (!this.resizeState || event.pointerId !== this.resizeState.pointerId) return;
    event.currentTarget.releasePointerCapture?.(event.pointerId);
    const width = this.resizeState.nextWidth;
    const height = this.resizeState.nextHeight;
    this.element.classList.remove("is-resizing");
    this.resizeState = null;
    setHudWidth(width);
    setHudHeight(height);
  }
}

export class HudConfigApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: `${MODULE_ID}-hud-config`,
    classes: [MODULE_ID, `${MODULE_ID}-hud-config-app`],
    tag: "form",
    window: {
      title: `${MODULE_ID}.hudConfig.title`,
      icon: "fa-solid fa-id-card-clip",
      resizable: true
    },
    position: {
      width: 500,
      height: 620
    },
    form: {
      handler: this.#onSubmit,
      submitOnChange: false,
      closeOnSubmit: true
    },
    actions: {
      addCompanion: this.#addCompanion,
      addSummon: this.#addSummon,
      removeCompanion: this.#removeCompanion,
      actorConfig: this.#actorConfig
    }
  };

  static PARTS = {
    form: {
      template: TEMPLATES.HUD_CONFIG
    }
  };

  constructor(hudController = game.cotsCharacterHud?.hud, options = {}) {
    super(options);
    this.hudController = hudController;
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const config = getCurrentUserConfig();
    const selectableActors = getSelectableActors().map(actor => ({
      ...actor,
      selectedMain: actor.uuid === config.mainActorUuid
    }));
    const companionActors = (await Promise.all(config.companionActorUuids.map(uuid => resolveActorReferenceUuid(uuid))))
      .filter(reference => reference?.actor && (reference.token ? canUserControlToken(reference.token) : canUserSelectActor(reference.actor)))
      .map(reference => getActorStats(reference.actor, reference));
    const excluded = new Set([config.mainActorUuid, ...config.companionActorUuids].filter(Boolean));

    return {
      ...context,
      config,
      selectableActors,
      companionActors,
      summonCandidates: getOwnedSceneTokenCandidates(excluded),
      hasSelectableActors: selectableActors.length > 0,
      hasCompanions: companionActors.length > 0
    };
  }

  static async #onSubmit(event, form, formData) {
    const data = formObject(form, formData);
    await updateCurrentUserConfig({
      mainActorUuid: String(data.mainActorUuid ?? ""),
      hudExpanded: Boolean(data.hudExpanded),
      companionTrayCollapsed: Boolean(data.companionTrayCollapsed)
    });
  }

  static async #addCompanion(event) {
    event.preventDefault();
    const select = this.element.querySelector('[name="addCompanionUuid"]');
    await addCompanionActor(select?.value ?? "");
    this.render({ force: true });
  }

  static async #addSummon(event, target) {
    event.preventDefault();
    await addCompanionActor(target.dataset.actorUuid);
    this.render({ force: true });
  }

  static async #removeCompanion(event, target) {
    event.preventDefault();
    await removeCompanionActor(target.dataset.actorUuid);
    this.render({ force: true });
  }

  static async #actorConfig(event, target) {
    event.preventDefault();
    const actor = await resolveActorUuid(target.dataset.actorUuid);
    if (actor) new ActorCinematicConfig(actor).render({ force: true });
  }
}
