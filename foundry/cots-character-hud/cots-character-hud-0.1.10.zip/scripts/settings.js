import { HOOKS, KEYBINDINGS, MODULE_ID, SETTINGS } from "./constants.js";
import { sanitizeColor } from "./actor-data-adapter.js";

function settingKey(key) {
  return `${MODULE_ID}.settings.${key}`;
}

function numberField({ min, max, step }) {
  const NumberField = globalThis.foundry?.data?.fields?.NumberField ?? globalThis.foundry?.fields?.NumberField;
  if (NumberField) return new NumberField({ nullable: false, min, max, step });
  return Number;
}

function colorField() {
  const ColorField = globalThis.foundry?.data?.fields?.ColorField ?? globalThis.foundry?.fields?.ColorField;
  if (ColorField) return new ColorField({ nullable: false });
  return String;
}

function notifySettingChanged(key, value) {
  Hooks.callAll(HOOKS.CONFIG_CHANGED, key, value);
}

function registerBoolean(key, { scope, config = true, restricted = false, default: defaultValue }) {
  game.settings.register(MODULE_ID, key, {
    name: `${settingKey(key)}.name`,
    hint: `${settingKey(key)}.hint`,
    scope,
    config,
    restricted,
    type: Boolean,
    default: defaultValue,
    onChange: value => notifySettingChanged(key, value)
  });
}

function registerNumber(key, { scope, config = true, restricted = false, default: defaultValue, min, max, step }) {
  game.settings.register(MODULE_ID, key, {
    name: `${settingKey(key)}.name`,
    hint: `${settingKey(key)}.hint`,
    scope,
    config,
    restricted,
    type: numberField({ min, max, step }),
    range: { min, max, step },
    default: defaultValue,
    onChange: value => notifySettingChanged(key, value)
  });
}

export function registerSettings() {
  registerBoolean(SETTINGS.ENABLE_PLAYER_HUD, {
    scope: "world",
    restricted: true,
    default: true
  });

  registerBoolean(SETTINGS.ENABLE_SPEAKER_OVERLAY, {
    scope: "world",
    restricted: true,
    default: true
  });

  registerNumber(SETTINGS.MAX_SPEAKERS, {
    scope: "world",
    restricted: true,
    default: 2,
    min: 1,
    max: 2,
    step: 1
  });

  registerNumber(SETTINGS.DEFAULT_LINGER, {
    scope: "world",
    restricted: true,
    default: 1.25,
    min: 0,
    max: 10,
    step: 0.25
  });

  registerBoolean(SETTINGS.ALLOW_PLAYER_ACCENTS, {
    scope: "world",
    restricted: true,
    default: true
  });

  registerBoolean(SETTINGS.GM_ONLY_CINEMATIC_CONFIG, {
    scope: "world",
    restricted: true,
    default: false
  });

  registerBoolean(SETTINGS.ALLOW_CLIENT_LINGER_OVERRIDE, {
    scope: "world",
    restricted: true,
    default: true
  });

  registerBoolean(SETTINGS.PRESENT_TEXT_CHAT, {
    scope: "world",
    restricted: true,
    default: true
  });

  registerNumber(SETTINGS.MAX_CONVERSATION_PARTICIPANTS, {
    scope: "world",
    restricted: true,
    default: 8,
    min: 2,
    max: 16,
    step: 1
  });

  registerBoolean(SETTINGS.ALLOW_PLAYER_PINNING, {
    scope: "world",
    restricted: true,
    default: false
  });

  registerBoolean(SETTINGS.PINNED_SURVIVE_SCENE_CHANGE, {
    scope: "world",
    restricted: true,
    default: false
  });

  registerBoolean(SETTINGS.SPEAKER_PRESENTATIONS_PAUSED, {
    scope: "world",
    restricted: true,
    default: false
  });

  registerBoolean(SETTINGS.HUD_ENABLED, {
    scope: "client",
    default: true
  });

  game.settings.register(MODULE_ID, SETTINGS.HUD_POSITION, {
    name: `${settingKey(SETTINGS.HUD_POSITION)}.name`,
    hint: `${settingKey(SETTINGS.HUD_POSITION)}.hint`,
    scope: "client",
    config: false,
    type: Object,
    default: { left: 110, top: 170 },
    onChange: value => notifySettingChanged(SETTINGS.HUD_POSITION, value)
  });

  registerNumber(SETTINGS.HUD_WIDTH, {
    scope: "client",
    default: 360,
    min: 280,
    max: 900,
    step: 10
  });

  registerNumber(SETTINGS.HUD_HEIGHT, {
    scope: "client",
    default: 360,
    min: 190,
    max: 900,
    step: 10
  });

  registerNumber(SETTINGS.HUD_SCALE, {
    scope: "client",
    default: 1,
    min: 0.75,
    max: 1.5,
    step: 0.05
  });

  game.settings.register(MODULE_ID, SETTINGS.HUD_BACKGROUND_COLOR, {
    name: `${settingKey(SETTINGS.HUD_BACKGROUND_COLOR)}.name`,
    hint: `${settingKey(SETTINGS.HUD_BACKGROUND_COLOR)}.hint`,
    scope: "client",
    config: true,
    type: colorField(),
    default: "#0a1210",
    onChange: value => notifySettingChanged(SETTINGS.HUD_BACKGROUND_COLOR, value)
  });

  game.settings.register(MODULE_ID, SETTINGS.HUD_GRADIENT_START, {
    name: `${settingKey(SETTINGS.HUD_GRADIENT_START)}.name`,
    hint: `${settingKey(SETTINGS.HUD_GRADIENT_START)}.hint`,
    scope: "client",
    config: true,
    type: colorField(),
    default: "#103529",
    onChange: value => notifySettingChanged(SETTINGS.HUD_GRADIENT_START, value)
  });

  game.settings.register(MODULE_ID, SETTINGS.HUD_GRADIENT_END, {
    name: `${settingKey(SETTINGS.HUD_GRADIENT_END)}.name`,
    hint: `${settingKey(SETTINGS.HUD_GRADIENT_END)}.hint`,
    scope: "client",
    config: true,
    type: colorField(),
    default: "#6e231c",
    onChange: value => notifySettingChanged(SETTINGS.HUD_GRADIENT_END, value)
  });

  game.settings.register(MODULE_ID, SETTINGS.HUD_BORDER_COLOR, {
    name: `${settingKey(SETTINGS.HUD_BORDER_COLOR)}.name`,
    hint: `${settingKey(SETTINGS.HUD_BORDER_COLOR)}.hint`,
    scope: "client",
    config: true,
    type: colorField(),
    default: "#c79b47",
    onChange: value => notifySettingChanged(SETTINGS.HUD_BORDER_COLOR, value)
  });

  game.settings.register(MODULE_ID, SETTINGS.HUD_TEXT_COLOR, {
    name: `${settingKey(SETTINGS.HUD_TEXT_COLOR)}.name`,
    hint: `${settingKey(SETTINGS.HUD_TEXT_COLOR)}.hint`,
    scope: "client",
    config: true,
    type: colorField(),
    default: "#f5ead1",
    onChange: value => notifySettingChanged(SETTINGS.HUD_TEXT_COLOR, value)
  });

  registerNumber(SETTINGS.HUD_PANEL_OPACITY, {
    scope: "client",
    default: 0.9,
    min: 0.2,
    max: 1,
    step: 0.05
  });

  registerBoolean(SETTINGS.COMPANION_TRAY_COLLAPSED, {
    scope: "client",
    default: false
  });

  registerBoolean(SETTINGS.SPEAKER_OVERLAY_ENABLED, {
    scope: "client",
    default: true
  });

  registerBoolean(SETTINGS.MANUAL_PRESENTATION_ENABLED, {
    scope: "client",
    default: true
  });

  registerBoolean(SETTINGS.VOICE_ACTIVITY_ENABLED, {
    scope: "client",
    default: false
  });

  game.settings.register(MODULE_ID, SETTINGS.VOICE_INPUT_DEVICE_ID, {
    name: `${settingKey(SETTINGS.VOICE_INPUT_DEVICE_ID)}.name`,
    hint: `${settingKey(SETTINGS.VOICE_INPUT_DEVICE_ID)}.hint`,
    scope: "client",
    config: false,
    type: String,
    default: "",
    onChange: value => notifySettingChanged(SETTINGS.VOICE_INPUT_DEVICE_ID, value)
  });

  registerNumber(SETTINGS.VOICE_ACTIVITY_THRESHOLD, {
    scope: "client",
    default: 0.055,
    min: 0.01,
    max: 0.2,
    step: 0.005
  });

  registerNumber(SETTINGS.VOICE_ACTIVITY_RELEASE_DELAY, {
    scope: "client",
    default: 0.65,
    min: 0.2,
    max: 3,
    step: 0.05
  });

  registerNumber(SETTINGS.SPEAKER_OVERLAY_SCALE, {
    scope: "client",
    default: 1,
    min: 0.75,
    max: 1.4,
    step: 0.05
  });

  registerBoolean(SETTINGS.SHOW_PARTICIPANT_CAROUSEL, {
    scope: "client",
    default: true
  });

  registerNumber(SETTINGS.PARTICIPANT_CAROUSEL_SCALE, {
    scope: "client",
    default: 1,
    min: 0.75,
    max: 1.25,
    step: 0.05
  });

  registerBoolean(SETTINGS.COMPACT_PARTICIPANT_CAROUSEL, {
    scope: "client",
    default: true
  });

  registerBoolean(SETTINGS.SHOW_TOKEN_SPEECH_BUBBLES, {
    scope: "client",
    default: false
  });

  registerNumber(SETTINGS.SPEAKER_LINGER_OVERRIDE, {
    scope: "client",
    default: 0,
    min: 0,
    max: 10,
    step: 0.25
  });

  game.settings.register(MODULE_ID, SETTINGS.GM_SPEAKER_ACTOR_UUID, {
    name: `${settingKey(SETTINGS.GM_SPEAKER_ACTOR_UUID)}.name`,
    hint: `${settingKey(SETTINGS.GM_SPEAKER_ACTOR_UUID)}.hint`,
    scope: "client",
    config: false,
    type: String,
    default: "",
    onChange: value => notifySettingChanged(SETTINGS.GM_SPEAKER_ACTOR_UUID, value)
  });

  game.settings.register(MODULE_ID, SETTINGS.GM_DOCK_OFFSET, {
    name: `${settingKey(SETTINGS.GM_DOCK_OFFSET)}.name`,
    hint: `${settingKey(SETTINGS.GM_DOCK_OFFSET)}.hint`,
    scope: "client",
    config: false,
    type: Object,
    default: { left: 84, top: 540 },
    onChange: value => notifySettingChanged(SETTINGS.GM_DOCK_OFFSET, value)
  });

  registerBoolean(SETTINGS.REDUCED_ANIMATION, {
    scope: "client",
    default: false
  });

  game.settings.register(MODULE_ID, SETTINGS.OVERLAY_LAYOUT, {
    name: `${settingKey(SETTINGS.OVERLAY_LAYOUT)}.name`,
    hint: `${settingKey(SETTINGS.OVERLAY_LAYOUT)}.hint`,
    scope: "client",
    config: false,
    type: Object,
    default: { left: 84, bottom: 74, width: 900 },
    onChange: value => notifySettingChanged(SETTINGS.OVERLAY_LAYOUT, value)
  });

  game.settings.register(MODULE_ID, SETTINGS.OVERLAY_BACKGROUND_COLOR, {
    name: `${settingKey(SETTINGS.OVERLAY_BACKGROUND_COLOR)}.name`,
    hint: `${settingKey(SETTINGS.OVERLAY_BACKGROUND_COLOR)}.hint`,
    scope: "client",
    config: true,
    type: colorField(),
    default: "#07100e",
    onChange: value => notifySettingChanged(SETTINGS.OVERLAY_BACKGROUND_COLOR, value)
  });

  game.settings.register(MODULE_ID, SETTINGS.OVERLAY_GRADIENT_START, {
    name: `${settingKey(SETTINGS.OVERLAY_GRADIENT_START)}.name`,
    hint: `${settingKey(SETTINGS.OVERLAY_GRADIENT_START)}.hint`,
    scope: "client",
    config: true,
    type: colorField(),
    default: "#103529",
    onChange: value => notifySettingChanged(SETTINGS.OVERLAY_GRADIENT_START, value)
  });

  game.settings.register(MODULE_ID, SETTINGS.OVERLAY_GRADIENT_END, {
    name: `${settingKey(SETTINGS.OVERLAY_GRADIENT_END)}.name`,
    hint: `${settingKey(SETTINGS.OVERLAY_GRADIENT_END)}.hint`,
    scope: "client",
    config: true,
    type: colorField(),
    default: "#6e231c",
    onChange: value => notifySettingChanged(SETTINGS.OVERLAY_GRADIENT_END, value)
  });

  game.settings.register(MODULE_ID, SETTINGS.OVERLAY_BORDER_COLOR, {
    name: `${settingKey(SETTINGS.OVERLAY_BORDER_COLOR)}.name`,
    hint: `${settingKey(SETTINGS.OVERLAY_BORDER_COLOR)}.hint`,
    scope: "client",
    config: true,
    type: colorField(),
    default: "#c79b47",
    onChange: value => notifySettingChanged(SETTINGS.OVERLAY_BORDER_COLOR, value)
  });

  registerNumber(SETTINGS.OVERLAY_PANEL_OPACITY, {
    scope: "client",
    default: 0.92,
    min: 0.2,
    max: 1,
    step: 0.05
  });

  registerNumber(SETTINGS.OVERLAY_PORTRAIT_OPACITY, {
    scope: "client",
    default: 1,
    min: 0.2,
    max: 1,
    step: 0.05
  });
}

export function registerSettingsMenus({ HudConfigApp, GmSpeakerPickerApp, OverlayAppearanceConfigApp, VoiceInputConfigApp }) {
  game.settings.registerMenu(MODULE_ID, "hudConfigMenu", {
    name: `${MODULE_ID}.menus.hudConfig.name`,
    label: `${MODULE_ID}.menus.hudConfig.label`,
    hint: `${MODULE_ID}.menus.hudConfig.hint`,
    icon: "fa-solid fa-id-card-clip",
    type: HudConfigApp,
    restricted: false
  });

  game.settings.registerMenu(MODULE_ID, "gmSpeakerPickerMenu", {
    name: `${MODULE_ID}.menus.gmSpeakerPicker.name`,
    label: `${MODULE_ID}.menus.gmSpeakerPicker.label`,
    hint: `${MODULE_ID}.menus.gmSpeakerPicker.hint`,
    icon: "fa-solid fa-theater-masks",
    type: GmSpeakerPickerApp,
    restricted: true
  });

  game.settings.registerMenu(MODULE_ID, "overlayAppearanceMenu", {
    name: `${MODULE_ID}.menus.overlayAppearance.name`,
    label: `${MODULE_ID}.menus.overlayAppearance.label`,
    hint: `${MODULE_ID}.menus.overlayAppearance.hint`,
    icon: "fa-solid fa-palette",
    type: OverlayAppearanceConfigApp,
    restricted: false
  });

  game.settings.registerMenu(MODULE_ID, "voiceInputMenu", {
    name: `${MODULE_ID}.menus.voiceInput.name`,
    label: `${MODULE_ID}.menus.voiceInput.label`,
    hint: `${MODULE_ID}.menus.voiceInput.hint`,
    icon: "fa-solid fa-microphone-lines",
    type: VoiceInputConfigApp,
    restricted: false
  });
}

export function registerKeybindings() {
  const normalPrecedence = globalThis.CONST?.KEYBINDING_PRECEDENCE?.NORMAL ?? 0;

  game.keybindings.register(MODULE_ID, KEYBINDINGS.HOLD_MAIN, {
    name: `${MODULE_ID}.keybindings.holdMain.name`,
    hint: `${MODULE_ID}.keybindings.holdMain.hint`,
    editable: [],
    precedence: normalPrecedence,
    onDown: () => game.cotsCharacterHud?.speaker?.startMainHold() ?? false,
    onUp: () => game.cotsCharacterHud?.speaker?.stopMainHold() ?? false
  });

  game.keybindings.register(MODULE_ID, KEYBINDINGS.TOGGLE_MAIN, {
    name: `${MODULE_ID}.keybindings.toggleMain.name`,
    hint: `${MODULE_ID}.keybindings.toggleMain.hint`,
    editable: [],
    precedence: normalPrecedence,
    onDown: () => game.cotsCharacterHud?.speaker?.toggleMainPresentation() ?? false
  });

  game.keybindings.register(MODULE_ID, KEYBINDINGS.HOLD_GM, {
    name: `${MODULE_ID}.keybindings.holdGm.name`,
    hint: `${MODULE_ID}.keybindings.holdGm.hint`,
    editable: [],
    restricted: true,
    precedence: normalPrecedence,
    onDown: () => game.cotsCharacterHud?.speaker?.startGmHold() ?? false,
    onUp: () => game.cotsCharacterHud?.speaker?.stopGmHold() ?? false
  });
}

export function getSetting(key) {
  return game.settings.get(MODULE_ID, key);
}

export async function setSetting(key, value) {
  return game.settings.set(MODULE_ID, key, value);
}

export function clampNumber(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, number));
}

export function getHudScale() {
  return clampNumber(getSetting(SETTINGS.HUD_SCALE), 0.75, 1.5, 1);
}

export function getHudWidth() {
  return Math.round(clampNumber(getSetting(SETTINGS.HUD_WIDTH), 280, Math.max(280, window.innerWidth - 24), 360));
}

export function getHudHeight() {
  return getConstrainedHudHeight(getSetting(SETTINGS.HUD_HEIGHT));
}

export async function setHudWidth(width) {
  return setSetting(SETTINGS.HUD_WIDTH, getConstrainedHudWidth(width));
}

export async function setHudHeight(height) {
  return setSetting(SETTINGS.HUD_HEIGHT, getConstrainedHudHeight(height));
}

export function getConstrainedHudWidth(width) {
  return Math.round(clampNumber(width, 280, Math.max(280, window.innerWidth - 24), 360));
}

export function getConstrainedHudHeight(height, { top = 12 } = {}) {
  const viewportTop = clampNumber(top, 0, Math.max(0, window.innerHeight - 48), 12);
  const maxHeight = Math.max(190, window.innerHeight - viewportTop - 12);
  return Math.round(clampNumber(height, 190, maxHeight, Math.min(360, maxHeight)));
}

export function getOverlayScale() {
  return clampNumber(getSetting(SETTINGS.SPEAKER_OVERLAY_SCALE), 0.75, 1.4, 1);
}

export function getMaxSpeakers() {
  return Math.round(clampNumber(getSetting(SETTINGS.MAX_SPEAKERS), 1, 2, 2));
}

export function getMaxConversationParticipants() {
  return Math.round(clampNumber(getSetting(SETTINGS.MAX_CONVERSATION_PARTICIPANTS), 2, 16, 8));
}

export function showParticipantCarousel() {
  return Boolean(getSetting(SETTINGS.SHOW_PARTICIPANT_CAROUSEL));
}

export function getParticipantCarouselScale() {
  return clampNumber(getSetting(SETTINGS.PARTICIPANT_CAROUSEL_SCALE), 0.75, 1.25, 1);
}

export function preferCompactParticipantCarousel() {
  return Boolean(getSetting(SETTINGS.COMPACT_PARTICIPANT_CAROUSEL));
}

export function speakerPresentationsPaused() {
  return Boolean(getSetting(SETTINGS.SPEAKER_PRESENTATIONS_PAUSED));
}

export function getLingerDuration() {
  const allowOverride = Boolean(getSetting(SETTINGS.ALLOW_CLIENT_LINGER_OVERRIDE));
  const override = allowOverride ? clampNumber(getSetting(SETTINGS.SPEAKER_LINGER_OVERRIDE), 0, 10, 0) : 0;
  if (override > 0) return override;
  return clampNumber(getSetting(SETTINGS.DEFAULT_LINGER), 0, 10, 1.25);
}

export function getHudPosition() {
  const position = getSetting(SETTINGS.HUD_POSITION);
  const left = clampNumber(position?.left, 0, Math.max(0, window.innerWidth - 120), 110);
  const top = clampNumber(position?.top, 0, Math.max(0, window.innerHeight - 120), 170);
  return { left, top };
}

export async function setHudPosition(position) {
  const left = Math.round(clampNumber(position?.left, 0, Math.max(0, window.innerWidth - 120), 110));
  const top = Math.round(clampNumber(position?.top, 0, Math.max(0, window.innerHeight - 120), 170));
  return setSetting(SETTINGS.HUD_POSITION, { left, top });
}

export function usesReducedAnimation() {
  return Boolean(getSetting(SETTINGS.REDUCED_ANIMATION)) || window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
}

export function getOverlayLayout() {
  const layout = getSetting(SETTINGS.OVERLAY_LAYOUT) ?? {};
  const defaultWidth = Math.min(900, Math.max(520, window.innerWidth - 430));
  const width = Math.round(clampNumber(layout.width, 420, Math.max(420, window.innerWidth - 32), defaultWidth));
  const left = Math.round(clampNumber(layout.left, 8, Math.max(8, window.innerWidth - width - 8), 84));
  const bottom = Math.round(clampNumber(layout.bottom, 24, Math.max(24, window.innerHeight - 220), 74));
  return { left, bottom, width };
}

export async function setOverlayLayout(layout) {
  const current = getOverlayLayout();
  const next = getConstrainedOverlayLayout({ ...current, ...layout });
  return setSetting(SETTINGS.OVERLAY_LAYOUT, next);
}

export function getConstrainedOverlayLayout(layout) {
  const width = Math.round(clampNumber(layout.width, 420, Math.max(420, window.innerWidth - 32), 900));
  const left = Math.round(clampNumber(layout.left, 8, Math.max(8, window.innerWidth - width - 8), 84));
  const bottom = Math.round(clampNumber(layout.bottom, 24, Math.max(24, window.innerHeight - 220), 74));
  return { left, bottom, width };
}

export function getOverlayAppearance() {
  return {
    backgroundColor: sanitizeColor(getSetting(SETTINGS.OVERLAY_BACKGROUND_COLOR), "#07100e"),
    gradientStart: sanitizeColor(getSetting(SETTINGS.OVERLAY_GRADIENT_START), "#103529"),
    gradientEnd: sanitizeColor(getSetting(SETTINGS.OVERLAY_GRADIENT_END), "#6e231c"),
    borderColor: sanitizeColor(getSetting(SETTINGS.OVERLAY_BORDER_COLOR), "#c79b47"),
    panelOpacity: clampNumber(getSetting(SETTINGS.OVERLAY_PANEL_OPACITY), 0.2, 1, 0.92),
    portraitOpacity: clampNumber(getSetting(SETTINGS.OVERLAY_PORTRAIT_OPACITY), 0.2, 1, 1)
  };
}

export function getHudAppearance() {
  return {
    backgroundColor: sanitizeColor(getSetting(SETTINGS.HUD_BACKGROUND_COLOR), "#0a1210"),
    gradientStart: sanitizeColor(getSetting(SETTINGS.HUD_GRADIENT_START), "#103529"),
    gradientEnd: sanitizeColor(getSetting(SETTINGS.HUD_GRADIENT_END), "#6e231c"),
    borderColor: sanitizeColor(getSetting(SETTINGS.HUD_BORDER_COLOR), "#c79b47"),
    textColor: sanitizeColor(getSetting(SETTINGS.HUD_TEXT_COLOR), "#f5ead1"),
    panelOpacity: clampNumber(getSetting(SETTINGS.HUD_PANEL_OPACITY), 0.2, 1, 0.9)
  };
}

export function getGmDockOffset() {
  return getConstrainedGmDockOffset(getSetting(SETTINGS.GM_DOCK_OFFSET) ?? {});
}

export async function setGmDockOffset(offset) {
  return setSetting(SETTINGS.GM_DOCK_OFFSET, getConstrainedGmDockOffset(offset));
}

export function getConstrainedGmDockOffset(offset, { dockRect = null } = {}) {
  const margin = 8;
  const dockWidth = Math.min(Number.isFinite(dockRect?.width) ? dockRect.width : 360, Math.max(80, window.innerWidth - margin * 2));
  const dockHeight = Math.min(Number.isFinite(dockRect?.height) ? dockRect.height : 38, Math.max(32, window.innerHeight - margin * 2));
  const fallbackLeft = Math.min(84, Math.max(margin, window.innerWidth - margin - dockWidth));
  const fallbackTop = Math.max(margin, window.innerHeight - dockHeight - 118);
  const maxLeft = Math.max(margin, window.innerWidth - margin - dockWidth);
  const maxTop = Math.max(margin, window.innerHeight - margin - dockHeight);
  const rawLeft = Number(offset?.left);
  const rawTop = Number(offset?.top);
  const inputLeft = Number.isFinite(rawLeft) && rawLeft >= margin ? rawLeft : fallbackLeft;
  const inputTop = Number.isFinite(rawTop) && rawTop >= margin ? rawTop : fallbackTop;
  const left = Math.round(clampNumber(inputLeft, margin, maxLeft, fallbackLeft));
  const top = Math.round(clampNumber(inputTop, margin, maxTop, fallbackTop));
  return { left, top };
}

export function hexToRgb(hex) {
  const color = sanitizeColor(hex, "#000000").slice(1);
  const expanded = color.length === 3 ? color.split("").map(character => character + character).join("") : color;
  const value = Number.parseInt(expanded, 16);
  return {
    r: (value >> 16) & 255,
    g: (value >> 8) & 255,
    b: value & 255
  };
}
