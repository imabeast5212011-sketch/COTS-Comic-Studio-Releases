import { MODULE_ID, SETTINGS, TEMPLATES } from "./constants.js";
import { getSetting, setSetting } from "./settings.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

function formObject(form, formData) {
  if (formData?.object) return formData.object;
  return Object.fromEntries(new FormData(form));
}

function stopStream(stream) {
  stream?.getTracks?.().forEach(track => track.stop());
}

function audioConstraints(deviceId = "") {
  const audio = {
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true
  };
  if (deviceId) audio.deviceId = { exact: deviceId };
  return { audio };
}

async function listAudioInputs(selectedDeviceId) {
  if (!navigator.mediaDevices?.enumerateDevices) return [];
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    return devices
      .filter(device => device.kind === "audioinput")
      .map((device, index) => ({
        id: device.deviceId,
        label: device.label || game.i18n.format(`${MODULE_ID}.voiceInput.unnamedDevice`, { number: index + 1 }),
        selected: device.deviceId === selectedDeviceId
      }));
  } catch (error) {
    console.warn(`${MODULE_ID} | Could not enumerate audio input devices`, error);
    return [];
  }
}

export class VoiceInputConfigApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: `${MODULE_ID}-voice-input-config`,
    classes: [MODULE_ID, `${MODULE_ID}-voice-input-config-app`],
    tag: "form",
    window: {
      title: `${MODULE_ID}.voiceInput.title`,
      icon: "fa-solid fa-microphone-lines",
      resizable: true
    },
    position: {
      width: 480,
      height: "auto"
    },
    form: {
      handler: this.#onSubmit,
      submitOnChange: false,
      closeOnSubmit: true
    },
    actions: {
      requestPermission: this.#requestPermission,
      refreshDevices: this.#refreshDevices,
      testInput: this.#testInput,
      clearDevice: this.#clearDevice
    }
  };

  static PARTS = {
    form: {
      template: TEMPLATES.VOICE_INPUT_CONFIG
    }
  };

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const selectedDeviceId = String(getSetting(SETTINGS.VOICE_INPUT_DEVICE_ID) ?? "");
    const devices = await listAudioInputs(selectedDeviceId);
    return {
      ...context,
      supportsMicrophone: Boolean(navigator.mediaDevices?.getUserMedia),
      selectedDeviceId,
      devices,
      hasDevices: devices.length > 0
    };
  }

  static async #onSubmit(event, form, formData) {
    const data = formObject(form, formData);
    await setSetting(SETTINGS.VOICE_INPUT_DEVICE_ID, String(data.deviceId ?? ""));
    await game.cotsCharacterHud?.voice?.restart?.();
    ui.notifications?.info(game.i18n.localize(`${MODULE_ID}.notifications.voiceInputSaved`));
  }

  static async #requestPermission(event) {
    event.preventDefault();
    if (!navigator.mediaDevices?.getUserMedia) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.noMicrophoneApi`));
      return;
    }

    let stream = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      ui.notifications?.info(game.i18n.localize(`${MODULE_ID}.notifications.voiceInputPermissionGranted`));
      this.render({ force: true });
    } catch (error) {
      console.warn(`${MODULE_ID} | Microphone permission request failed`, error);
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.voiceActivityDenied`));
    } finally {
      stopStream(stream);
    }
  }

  static async #refreshDevices(event) {
    event.preventDefault();
    this.render({ force: true });
  }

  static async #testInput(event) {
    event.preventDefault();
    if (!navigator.mediaDevices?.getUserMedia) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.noMicrophoneApi`));
      return;
    }

    const deviceId = String(this.element.querySelector('[name="deviceId"]')?.value ?? "");
    let stream = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia(audioConstraints(deviceId));
      ui.notifications?.info(game.i18n.localize(`${MODULE_ID}.notifications.voiceInputTestSucceeded`));
    } catch (error) {
      console.warn(`${MODULE_ID} | Microphone test failed`, error);
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.voiceInputTestFailed`));
    } finally {
      stopStream(stream);
    }
  }

  static async #clearDevice(event) {
    event.preventDefault();
    await setSetting(SETTINGS.VOICE_INPUT_DEVICE_ID, "");
    await game.cotsCharacterHud?.voice?.restart?.();
    this.render({ force: true });
  }
}
