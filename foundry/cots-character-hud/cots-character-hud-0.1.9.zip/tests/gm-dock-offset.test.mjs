import assert from "node:assert/strict";

globalThis.window = {
  innerWidth: 1280,
  innerHeight: 720
};

const { getConstrainedGmDockOffset } = await import("../scripts/settings.js");

const dockRect = { width: 420, height: 38 };
const migratedDock = getConstrainedGmDockOffset({ left: 0, top: -40 }, { dockRect });

assert.ok(migratedDock.left >= 8);
assert.ok(migratedDock.top >= 8);
assert.ok(migratedDock.left + dockRect.width <= window.innerWidth - 8);
assert.ok(migratedDock.top + dockRect.height <= window.innerHeight - 8);

const dock = getConstrainedGmDockOffset({ left: -9999, top: 9999 }, { dockRect });

assert.ok(dock.left >= 8);
assert.ok(dock.top >= 8);
assert.ok(dock.left + dockRect.width <= window.innerWidth - 8);
assert.ok(dock.top + dockRect.height <= window.innerHeight - 8);

console.log("GM dock offset tests passed");
