# Assets

Place optional cinematic portraits or development fixture images here.

No Lady Rose image was available in the provided attachment folder or standard workspace search, so the MVP does not copy or bundle that image.
