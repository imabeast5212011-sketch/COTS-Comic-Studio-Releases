import { FLAGS, HOOKS, MODULE_ID, SETTINGS } from "./constants.js";
import { getSetting, setSetting } from "./settings.js";

const DEFAULT_USER_CONFIG = Object.freeze({
  mainActorUuid: "",
  companionActorUuids: [],
  hudExpanded: true,
  companionTrayCollapsed: undefined
});

function normalizeUuidArray(value) {
  if (!Array.isArray(value)) return [];
  return Array.from(new Set(value.filter(uuid => typeof uuid === "string" && uuid.trim())));
}

function readUserFlag() {
  const flag = game.user?.getFlag(MODULE_ID, FLAGS.USER_CONFIG) ?? {};
  return flag && typeof flag === "object" && !Array.isArray(flag) ? flag : {};
}

export function getCurrentUserConfig() {
  const flag = readUserFlag();
  const companionTrayCollapsed = typeof flag.companionTrayCollapsed === "boolean"
    ? flag.companionTrayCollapsed
    : Boolean(getSetting(SETTINGS.COMPANION_TRAY_COLLAPSED));

  return {
    ...DEFAULT_USER_CONFIG,
    mainActorUuid: typeof flag.mainActorUuid === "string" ? flag.mainActorUuid : "",
    companionActorUuids: normalizeUuidArray(flag.companionActorUuids),
    hudExpanded: flag.hudExpanded !== false,
    companionTrayCollapsed
  };
}

export function getGmSpeakerActorUuid() {
  const settingValue = getSetting(SETTINGS.GM_SPEAKER_ACTOR_UUID);
  if (typeof settingValue === "string" && settingValue.trim()) return settingValue;

  const legacyValue = readUserFlag().gmSpeakerActorUuid;
  return typeof legacyValue === "string" ? legacyValue : "";
}

export async function setGmSpeakerActorUuid(uuid) {
  const next = typeof uuid === "string" ? uuid : "";
  await setSetting(SETTINGS.GM_SPEAKER_ACTOR_UUID, next);
  Hooks.callAll(HOOKS.CONFIG_CHANGED, SETTINGS.GM_SPEAKER_ACTOR_UUID, next);
  return next;
}

export async function migrateGmSpeakerActorSetting() {
  if (!game.user?.isGM) return getGmSpeakerActorUuid();

  const existing = getSetting(SETTINGS.GM_SPEAKER_ACTOR_UUID);
  if (typeof existing === "string" && existing.trim()) return existing;

  const legacyValue = readUserFlag().gmSpeakerActorUuid;
  if (typeof legacyValue === "string" && legacyValue.trim()) {
    await setGmSpeakerActorUuid(legacyValue);
    return legacyValue;
  }
  return "";
}

export async function updateCurrentUserConfig(patch) {
  await migrateGmSpeakerActorSetting();

  const current = getCurrentUserConfig();
  const next = {
    ...current,
    ...patch,
    companionActorUuids: normalizeUuidArray(patch.companionActorUuids ?? current.companionActorUuids)
  };

  await game.user.setFlag(MODULE_ID, FLAGS.USER_CONFIG, next);
  if (typeof patch.companionTrayCollapsed === "boolean") {
    await setSetting(SETTINGS.COMPANION_TRAY_COLLAPSED, patch.companionTrayCollapsed);
  }
  Hooks.callAll(HOOKS.USER_CONFIG_CHANGED, next, current);
  Hooks.callAll(HOOKS.CONFIG_CHANGED, "userConfig", next);
  return next;
}

export async function addCompanionActor(uuid) {
  if (!uuid) return getCurrentUserConfig();
  const current = getCurrentUserConfig();
  const companionActorUuids = normalizeUuidArray([...current.companionActorUuids, uuid]);
  return updateCurrentUserConfig({ companionActorUuids });
}

export async function removeCompanionActor(uuid) {
  const current = getCurrentUserConfig();
  const companionActorUuids = current.companionActorUuids.filter(existing => existing !== uuid);
  return updateCurrentUserConfig({ companionActorUuids });
}