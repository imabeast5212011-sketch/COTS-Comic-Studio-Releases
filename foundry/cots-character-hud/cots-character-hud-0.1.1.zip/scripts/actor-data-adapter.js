import { FLAGS, MODULE_ID, ownerPermissionLevel } from "./constants.js";

const DEFAULT_ACCENT = "#c79b47";
const MAJOR_CONDITION_ORDER = [
  "dead",
  "defeated",
  "unconscious",
  "incapacitated",
  "paralyzed",
  "stunned",
  "restrained",
  "poisoned",
  "frightened",
  "charmed",
  "prone"
];

function getProperty(object, path) {
  if (!object || !path) return undefined;
  const foundryGet = globalThis.foundry?.utils?.getProperty;
  if (foundryGet) return foundryGet(object, path);
  return path.split(".").reduce((value, part) => value?.[part], object);
}

function firstDefined(...values) {
  return values.find(value => value !== undefined && value !== null && value !== "");
}

function titleCase(value) {
  return String(value ?? "")
    .replace(/[-_]/g, " ")
    .replace(/\b\w/g, character => character.toUpperCase());
}

function numberOrNull(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") {
    const match = value.match(/-?\d+(\.\d+)?/);
    if (match) return Number(match[0]);
  }
  return null;
}

function normalizePath(path) {
  return typeof path === "string" && path.trim() ? path.trim() : "";
}

export function sanitizeColor(value, fallback = DEFAULT_ACCENT) {
  if (typeof value !== "string") return fallback;
  const color = value.trim();
  return /^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/.test(color) ? color : fallback;
}

export function getActorConfig(actor) {
  const raw = actor?.getFlag?.(MODULE_ID, FLAGS.ACTOR_CONFIG) ?? {};
  const sidePreference = ["automatic", "left", "right"].includes(raw.sidePreference) ? raw.sidePreference : "automatic";
  return {
    displayName: typeof raw.displayName === "string" ? raw.displayName.trim() : "",
    portraitPath: normalizePath(raw.portraitPath),
    accentColor: sanitizeColor(raw.accentColor, DEFAULT_ACCENT),
    sidePreference,
    flipPortrait: raw.flipPortrait === true
  };
}

export function buildActorSnapshot(actor) {
  if (!actor) return null;
  const config = getActorConfig(actor);
  return {
    actorUuid: actor.uuid,
    name: config.displayName || actor.name || "",
    img: config.portraitPath || actor.img || "icons/svg/mystery-man.svg",
    accentColor: config.accentColor,
    sidePreference: config.sidePreference,
    flipPortrait: config.flipPortrait
  };
}

export function sanitizeActorSnapshot(snapshot) {
  if (!snapshot || typeof snapshot !== "object") return null;
  const sidePreference = ["automatic", "left", "right"].includes(snapshot.sidePreference)
    ? snapshot.sidePreference
    : "automatic";
  return {
    actorUuid: typeof snapshot.actorUuid === "string" ? snapshot.actorUuid : "",
    name: typeof snapshot.name === "string" ? snapshot.name.slice(0, 120) : "",
    img: normalizePath(snapshot.img) || "icons/svg/mystery-man.svg",
    accentColor: sanitizeColor(snapshot.accentColor, DEFAULT_ACCENT),
    sidePreference,
    flipPortrait: snapshot.flipPortrait === true
  };
}

export function canUserSelectActor(actor, user = game.user) {
  if (!actor || !user) return false;
  if (user.isGM) return true;
  return actor.testUserPermission?.(user, ownerPermissionLevel()) === true;
}

export async function resolveActorUuid(uuid) {
  if (typeof uuid !== "string" || !uuid.trim()) return null;
  try {
    if (globalThis.fromUuid) {
      const document = await fromUuid(uuid);
      return document?.documentName === "Actor" ? document : null;
    }
    if (uuid.startsWith("Actor.")) return game.actors.get(uuid.split(".")[1]) ?? null;
  } catch (error) {
    console.warn(`${MODULE_ID} | Could not resolve actor UUID ${uuid}`, error);
  }
  return null;
}

export function getSelectableActors(user = game.user) {
  return game.actors
    .filter(actor => canUserSelectActor(actor, user))
    .sort((a, b) => a.name.localeCompare(b.name, game.i18n.lang))
    .map(actor => ({
      id: actor.id,
      uuid: actor.uuid,
      name: actor.name,
      img: actor.img || "icons/svg/mystery-man.svg",
      type: actor.type
    }));
}

function getMovementLabel(actor) {
  const movement = getProperty(actor, "system.attributes.movement");
  const legacySpeed = firstDefined(
    getProperty(actor, "system.attributes.speed.value"),
    getProperty(actor, "system.attributes.speed")
  );
  const units = firstDefined(
    movement?.units,
    getProperty(actor, "system.attributes.speed.units"),
    game.i18n.localize("DND5E.DistFt") === "DND5E.DistFt" ? "ft" : game.i18n.localize("DND5E.DistFt")
  );

  if (movement && typeof movement === "object") {
    const parts = ["walk", "fly", "swim", "climb", "burrow"]
      .map(type => {
        const value = numberOrNull(movement[type]);
        return value && value > 0 ? `${titleCase(type)} ${value} ${units}` : null;
      })
      .filter(Boolean);
    if (parts.length) return parts.join(", ");
  }

  if (legacySpeed && typeof legacySpeed === "object") {
    const value = firstDefined(legacySpeed.value, legacySpeed.walk);
    return value ? String(value) : "";
  }
  return legacySpeed ? String(legacySpeed) : "";
}

function getSpellSlots(actor) {
  const spells = getProperty(actor, "system.spells") ?? {};
  if (!spells || typeof spells !== "object") return [];

  return Object.entries(spells)
    .map(([key, slot]) => {
      if (!slot || typeof slot !== "object") return null;
      const value = numberOrNull(slot.value) ?? 0;
      const max = numberOrNull(firstDefined(slot.max, slot.override)) ?? 0;
      if (max <= 0 && value <= 0) return null;
      const level = key.match(/\d+/)?.[0];
      const label = key === "pact" ? "Pact" : level ? `L${level}` : titleCase(key);
      return { key, label, value, max };
    })
    .filter(Boolean)
    .sort((a, b) => {
      if (a.key === "pact") return 1;
      if (b.key === "pact") return -1;
      return a.key.localeCompare(b.key, game.i18n.lang, { numeric: true });
    });
}

function getResources(actor) {
  const paths = [
    ["primary", "system.resources.primary"],
    ["secondary", "system.resources.secondary"],
    ["tertiary", "system.resources.tertiary"],
    ["legendary", "system.resources.legact"],
    ["legendaryResistances", "system.resources.legres"],
    ["hitDice", "system.attributes.hd"],
    ["actions", "system.attributes.actions"]
  ];

  return paths
    .map(([key, path]) => {
      const resource = getProperty(actor, path);
      if (!resource || typeof resource !== "object") return null;
      const value = numberOrNull(resource.value) ?? 0;
      const max = numberOrNull(resource.max) ?? 0;
      const label = resource.label || titleCase(key);
      if (max <= 0 && value <= 0) return null;
      return { key, label, value, max };
    })
    .filter(Boolean);
}

function collectStatuses(actor) {
  const statuses = new Set();
  for (const effect of actor?.effects ?? []) {
    if (effect.disabled) continue;
    if (effect.statuses instanceof Set) {
      for (const status of effect.statuses) statuses.add(String(status).toLowerCase());
    }
    const statusId = effect.statuses?.values?.().next?.().value ?? effect.statusId ?? effect.getFlag?.("core", "statusId");
    if (statusId) statuses.add(String(statusId).toLowerCase());
    if (effect.name) statuses.add(String(effect.name).toLowerCase());
  }

  const token = findActiveToken(actor);
  const tokenStatuses = token?.document?.statuses;
  if (tokenStatuses instanceof Set) {
    for (const status of tokenStatuses) statuses.add(String(status).toLowerCase());
  }

  const special = globalThis.CONFIG?.specialStatusEffects ?? {};
  for (const value of Object.values(special)) {
    if (value && statuses.has(String(value).toLowerCase())) statuses.add(String(value).toLowerCase());
  }
  return statuses;
}

function getMajorStatus(actor, hp) {
  const statuses = collectStatuses(actor);
  for (const condition of MAJOR_CONDITION_ORDER) {
    if (statuses.has(condition)) return { label: titleCase(condition), cssClass: condition };
  }
  if (Number.isFinite(hp.value) && hp.value <= 0 && Number.isFinite(hp.max) && hp.max > 0) {
    return { label: "Unconscious", cssClass: "unconscious" };
  }
  return null;
}

export function getActorStats(actor) {
  const config = getActorConfig(actor);
  const hpValue = numberOrNull(getProperty(actor, "system.attributes.hp.value")) ?? 0;
  const hpMax = numberOrNull(getProperty(actor, "system.attributes.hp.max")) ?? 0;
  const hpTemp = numberOrNull(getProperty(actor, "system.attributes.hp.temp")) ?? 0;
  const hpTempMax = numberOrNull(getProperty(actor, "system.attributes.hp.tempmax")) ?? 0;
  const hp = {
    value: hpValue,
    max: hpMax,
    temp: hpTemp,
    tempmax: hpTempMax,
    maxSafe: Math.max(1, hpMax),
    pct: hpMax > 0 ? Math.max(0, Math.min(100, Math.round((hpValue / hpMax) * 100))) : 0
  };

  const spellSlots = getSpellSlots(actor);
  const resources = spellSlots.length ? [] : getResources(actor);
  const state = getMajorStatus(actor, hp);

  return {
    uuid: actor.uuid,
    id: actor.id,
    type: actor.type,
    name: config.displayName || actor.name || "",
    baseName: actor.name || "",
    img: config.portraitPath || actor.img || "icons/svg/mystery-man.svg",
    actorImg: actor.img || "icons/svg/mystery-man.svg",
    accentColor: config.accentColor,
    sidePreference: config.sidePreference,
    flipPortrait: config.flipPortrait,
    hp,
    ac: firstDefined(
      numberOrNull(getProperty(actor, "system.attributes.ac.value")),
      numberOrNull(getProperty(actor, "system.attributes.ac.flat")),
      numberOrNull(getProperty(actor, "system.attributes.ac.base")),
      ""
    ),
    movement: getMovementLabel(actor),
    spellSlots,
    resources,
    state,
    hasSpellSlots: spellSlots.length > 0,
    hasResources: resources.length > 0
  };
}

export function findActiveToken(actor) {
  if (!actor || !globalThis.canvas?.ready) return null;
  const tokens = canvas.tokens?.placeables ?? [];
  return tokens.find(token => {
    const tokenActor = token.actor;
    return tokenActor?.uuid === actor.uuid || tokenActor?.id === actor.id || token.document?.actorId === actor.id;
  }) ?? null;
}

export function selectActorToken(actor, { pan = false } = {}) {
  const token = findActiveToken(actor);
  if (!token) {
    ui.notifications?.warn(game.i18n.format(`${MODULE_ID}.notifications.noActiveToken`, { name: actor?.name ?? "" }));
    return false;
  }

  const canControl = token.can?.(game.user, "control") ?? token.isOwner;
  if (!canControl) {
    ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.cannotControlToken`));
    return false;
  }

  token.control({ releaseOthers: true, pan });
  if (pan && token.center && canvas.animatePan) {
    canvas.animatePan({ x: token.center.x, y: token.center.y, duration: 350 });
  }
  return true;
}

export function openActorSheet(actor) {
  if (!actor?.sheet) return false;
  actor.sheet.render({ force: true });
  return true;
}

export function getOwnedSceneTokenCandidates(excludedUuids = new Set()) {
  if (!globalThis.canvas?.ready) return [];
  const seen = new Set(excludedUuids);
  const candidates = [];
  for (const token of canvas.tokens?.placeables ?? []) {
    const actor = token.actor;
    if (!actor || seen.has(actor.uuid) || !canUserSelectActor(actor)) continue;
    seen.add(actor.uuid);
    candidates.push({
      uuid: actor.uuid,
      name: token.name || actor.name,
      img: actor.img || token.document?.texture?.src || "icons/svg/mystery-man.svg",
      actorName: actor.name,
      tokenName: token.name,
      temporary: actor.isToken === true || !game.actors.get(actor.id)
    });
  }
  return candidates.sort((a, b) => a.name.localeCompare(b.name, game.i18n.lang));
}
