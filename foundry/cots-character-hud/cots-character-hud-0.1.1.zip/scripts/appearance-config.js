import { MODULE_ID, SETTINGS, TEMPLATES } from "./constants.js";
import { sanitizeColor } from "./actor-data-adapter.js";
import { clampNumber, getOverlayAppearance, hexToRgb, setSetting } from "./settings.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

const DEFAULT_APPEARANCE = Object.freeze({
  backgroundColor: "#07100e",
  gradientStart: "#103529",
  gradientEnd: "#6e231c",
  borderColor: "#c79b47",
  panelOpacity: 0.92,
  portraitOpacity: 1
});

function formObject(form, formData) {
  if (formData?.object) return formData.object;
  return Object.fromEntries(new FormData(form));
}

function percent(value) {
  return `${Math.round(Number(value) * 100)}%`;
}

export class OverlayAppearanceConfigApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: `${MODULE_ID}-overlay-appearance-config`,
    classes: [MODULE_ID, `${MODULE_ID}-overlay-appearance-config-app`],
    tag: "form",
    window: {
      title: `${MODULE_ID}.appearance.title`,
      icon: "fa-solid fa-palette",
      resizable: true
    },
    position: {
      width: 520,
      height: "auto"
    },
    form: {
      handler: this.#onSubmit,
      submitOnChange: false,
      closeOnSubmit: true
    },
    actions: {
      resetAppearance: this.#resetAppearance
    }
  };

  static PARTS = {
    form: {
      template: TEMPLATES.OVERLAY_APPEARANCE_CONFIG
    }
  };

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const appearance = getOverlayAppearance();
    return {
      ...context,
      appearance,
      panelOpacityPercent: percent(appearance.panelOpacity),
      portraitOpacityPercent: percent(appearance.portraitOpacity)
    };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    this.element.querySelectorAll("[data-cots-appearance-control]").forEach(control => {
      control.addEventListener("input", () => this.#syncPreview());
    });
    this.#syncPreview();
  }

  static async #onSubmit(event, form, formData) {
    const data = formObject(form, formData);
    await setSetting(SETTINGS.OVERLAY_BACKGROUND_COLOR, sanitizeColor(String(data.backgroundColor ?? ""), DEFAULT_APPEARANCE.backgroundColor));
    await setSetting(SETTINGS.OVERLAY_GRADIENT_START, sanitizeColor(String(data.gradientStart ?? ""), DEFAULT_APPEARANCE.gradientStart));
    await setSetting(SETTINGS.OVERLAY_GRADIENT_END, sanitizeColor(String(data.gradientEnd ?? ""), DEFAULT_APPEARANCE.gradientEnd));
    await setSetting(SETTINGS.OVERLAY_BORDER_COLOR, sanitizeColor(String(data.borderColor ?? ""), DEFAULT_APPEARANCE.borderColor));
    await setSetting(SETTINGS.OVERLAY_PANEL_OPACITY, clampNumber(data.panelOpacity, 0.2, 1, DEFAULT_APPEARANCE.panelOpacity));
    await setSetting(SETTINGS.OVERLAY_PORTRAIT_OPACITY, clampNumber(data.portraitOpacity, 0.2, 1, DEFAULT_APPEARANCE.portraitOpacity));
  }

  static async #resetAppearance(event) {
    event.preventDefault();
    await setSetting(SETTINGS.OVERLAY_BACKGROUND_COLOR, DEFAULT_APPEARANCE.backgroundColor);
    await setSetting(SETTINGS.OVERLAY_GRADIENT_START, DEFAULT_APPEARANCE.gradientStart);
    await setSetting(SETTINGS.OVERLAY_GRADIENT_END, DEFAULT_APPEARANCE.gradientEnd);
    await setSetting(SETTINGS.OVERLAY_BORDER_COLOR, DEFAULT_APPEARANCE.borderColor);
    await setSetting(SETTINGS.OVERLAY_PANEL_OPACITY, DEFAULT_APPEARANCE.panelOpacity);
    await setSetting(SETTINGS.OVERLAY_PORTRAIT_OPACITY, DEFAULT_APPEARANCE.portraitOpacity);
    this.render({ force: true });
  }

  #syncPreview() {
    const preview = this.element.querySelector("[data-cots-appearance-preview]");
    if (!preview) return;

    const form = this.element;
    const backgroundColor = sanitizeColor(form.elements.backgroundColor?.value, DEFAULT_APPEARANCE.backgroundColor);
    const gradientStart = sanitizeColor(form.elements.gradientStart?.value, DEFAULT_APPEARANCE.gradientStart);
    const gradientEnd = sanitizeColor(form.elements.gradientEnd?.value, DEFAULT_APPEARANCE.gradientEnd);
    const borderColor = sanitizeColor(form.elements.borderColor?.value, DEFAULT_APPEARANCE.borderColor);
    const panelOpacity = clampNumber(form.elements.panelOpacity?.value, 0.2, 1, DEFAULT_APPEARANCE.panelOpacity);
    const portraitOpacity = clampNumber(form.elements.portraitOpacity?.value, 0.2, 1, DEFAULT_APPEARANCE.portraitOpacity);
    const background = hexToRgb(backgroundColor);

    preview.style.setProperty("--cots-overlay-panel-bg", `rgba(${background.r}, ${background.g}, ${background.b}, ${panelOpacity})`);
    preview.style.setProperty("--cots-overlay-gradient-start", gradientStart);
    preview.style.setProperty("--cots-overlay-gradient-end", gradientEnd);
    preview.style.setProperty("--cots-overlay-border-color", borderColor);
    preview.style.setProperty("--cots-overlay-portrait-opacity", String(portraitOpacity));

    this.element.querySelector('[data-cots-output-for="panelOpacity"]').value = percent(panelOpacity);
    this.element.querySelector('[data-cots-output-for="portraitOpacity"]').value = percent(portraitOpacity);
  }
}