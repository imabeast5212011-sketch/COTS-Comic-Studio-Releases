import { FLAGS, HOOKS, MODULE_ID, SETTINGS, SOCKET_TYPES, TEMPLATES, randomId } from "./constants.js";
import {
  buildActorSnapshot,
  canUserSelectActor,
  getActorStats,
  resolveActorUuid,
  sanitizeActorSnapshot
} from "./actor-data-adapter.js";
import {
  getCurrentUserConfig,
  getGmSpeakerActorUuid,
  migrateGmSpeakerActorSetting,
  setGmSpeakerActorUuid
} from "./user-config.js";
import {
  getConstrainedOverlayLayout,
  getLingerDuration,
  getMaxSpeakers,
  getOverlayAppearance,
  getOverlayLayout,
  getOverlayScale,
  getSetting,
  hexToRgb,
  setOverlayLayout,
  setSetting,
  usesReducedAnimation
} from "./settings.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

function isObject(value) {
  return value && typeof value === "object" && !Array.isArray(value);
}

function actorSpeakerData(actor, snapshot, side) {
  const data = actor ? getActorStats(actor) : sanitizeActorSnapshot(snapshot);
  if (!data) return null;
  const sidePreference = data.sidePreference ?? "automatic";
  const flipPortrait = data.flipPortrait === true || (side === "right" && sidePreference === "automatic");
  return {
    uuid: actor?.uuid ?? data.actorUuid ?? "",
    name: data.name || "Unknown Speaker",
    img: data.img || "icons/svg/mystery-man.svg",
    accentColor: data.accentColor,
    sidePreference,
    flipPortrait
  };
}

function isNarrativeChatMessage(message) {
  const rolls = message.rolls;
  const rollCount = Array.isArray(rolls) ? rolls.length : rolls?.size ?? 0;
  if (rollCount > 0 || message.isRoll) return false;

  const rollTypes = new Set([
    globalThis.CONST?.CHAT_MESSAGE_TYPES?.ROLL,
    globalThis.CONST?.CHAT_MESSAGE_TYPES?.EMOTE
  ].filter(value => value !== undefined));
  if (rollTypes.has(message.type) && message.type === globalThis.CONST?.CHAT_MESSAGE_TYPES?.ROLL) return false;

  const content = String(message.content ?? "").replace(/<[^>]*>/g, "").trim();
  return content.length > 0;
}

function chatUserFromMessage(message, userId) {
  const id = userId || message.user?.id || message.user;
  return id ? game.users.get(id) : null;
}

async function resolveUserChatActor(user) {
  const character = user?.character;
  if (character?.documentName === "Actor") return character;
  if (typeof character === "string") return game.actors.get(character) ?? null;

  const userConfig = user?.getFlag?.(MODULE_ID, FLAGS.USER_CONFIG) ?? {};
  const mainActorUuid = typeof userConfig.mainActorUuid === "string" ? userConfig.mainActorUuid : "";
  return mainActorUuid ? resolveActorUuid(mainActorUuid) : null;
}

async function chatActorFromMessage(message, user) {
  const speaker = message.speaker ?? {};
  if (speaker.scene && speaker.token && canvas?.scene?.id === speaker.scene) {
    const token = canvas.tokens?.placeables?.find(placeable => placeable.id === speaker.token || placeable.document?.id === speaker.token);
    if (token?.actor) return token.actor;
  }
  if (speaker.actor) return game.actors.get(speaker.actor) ?? null;
  return resolveUserChatActor(user);
}

export class SpeakerController {
  constructor() {
    this.socketController = null;
    this.element = null;
    this.slots = { left: null, right: null };
    this.removeTimers = new Map();
    this.holdState = { main: false, gm: false };
    this.voiceActive = false;
    this.toggleMainActive = false;
    this.dragState = null;
    this.resizeState = null;
    this._boundRefresh = this.render.bind(this);
    this._boundUserConnected = this._onUserConnected.bind(this);
    this._boundChatMessage = this._onCreateChatMessage.bind(this);
    this._boundActorDeleted = this._onDeleteActor.bind(this);
    this.gmPicker = null;
  }

  setSocketController(socketController) {
    this.socketController = socketController;
  }

  initialize() {
    if (game.user.isGM) migrateGmSpeakerActorSetting();
    Hooks.on(HOOKS.CONFIG_CHANGED, this._boundRefresh);
    Hooks.on("canvasReady", this._boundRefresh);
    Hooks.on("userConnected", this._boundUserConnected);
    Hooks.on("createChatMessage", this._boundChatMessage);
    Hooks.on("deleteActor", this._boundActorDeleted);
    window.addEventListener("resize", this._boundRefresh);
    this.render();
  }

  destroy() {
    Hooks.off(HOOKS.CONFIG_CHANGED, this._boundRefresh);
    Hooks.off("canvasReady", this._boundRefresh);
    Hooks.off("userConnected", this._boundUserConnected);
    Hooks.off("createChatMessage", this._boundChatMessage);
    Hooks.off("deleteActor", this._boundActorDeleted);
    window.removeEventListener("resize", this._boundRefresh);
    this.remove();
  }

  async startMainHold() {
    if (!this.#manualPresentationEnabled()) return false;
    if (this.holdState.main) return false;
    this.holdState.main = true;
    const actor = await this.#getMainActor();
    const started = await this.socketController?.emitStart(actor, { mode: "main", source: "hold" });
    if (!started) this.holdState.main = false;
    return Boolean(started);
  }

  async stopMainHold() {
    if (!this.holdState.main) return false;
    this.holdState.main = false;
    const actor = await this.#getMainActor();
    return this.socketController?.emitStop(actor, { mode: "main" }) ?? false;
  }

  async toggleMainPresentation() {
    if (!this.#manualPresentationEnabled()) return false;
    const actor = await this.#getMainActor();
    if (!actor) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.noMainActor`));
      return false;
    }
    if (this.toggleMainActive) {
      this.toggleMainActive = false;
      return this.socketController?.emitStop(actor, { mode: "main" }) ?? false;
    }
    const started = await this.socketController?.emitStart(actor, { mode: "main", source: "toggle" });
    this.toggleMainActive = Boolean(started);
    return Boolean(started);
  }

  async startGmHold() {
    if (!this.#manualPresentationEnabled()) return false;
    if (!game.user.isGM || this.holdState.gm) return false;
    this.holdState.gm = true;
    const actor = await this.#getGmSpeakerActor();
    const started = await this.socketController?.emitStart(actor, { mode: "gm", source: "gm-hold" });
    if (!started) this.holdState.gm = false;
    return Boolean(started);
  }

  async stopGmHold() {
    if (!game.user.isGM || !this.holdState.gm) return false;
    this.holdState.gm = false;
    const actor = await this.#getGmSpeakerActor();
    return this.socketController?.emitStop(actor, { mode: "gm" }) ?? false;
  }

  async previewActor(actor) {
    if (!actor) return;
    const message = this.#buildLocalStartMessage(actor, "preview", "preview");
    await this.#startSpeaker(message, { local: true });
    window.setTimeout(() => this.#stopSpeaker({
      userId: game.user.id,
      actorUuid: actor.uuid,
      linger: getLingerDuration()
    }), 1600);
  }

  async startVoiceActivity() {
    if (this.voiceActive) return false;
    this.voiceActive = true;
    const actor = await this.#getMainActor();
    const started = await this.socketController?.emitStart(actor, { mode: "main", source: "voice" });
    if (!started) this.voiceActive = false;
    return Boolean(started);
  }

  async stopVoiceActivity() {
    if (!this.voiceActive) return false;
    this.voiceActive = false;
    const actor = await this.#getMainActor();
    return this.socketController?.emitStop(actor, { mode: "main" }) ?? false;
  }

  async handleSocketMessage(message, { local = false } = {}) {
    if (!isObject(message) || message.v !== 1 || typeof message.type !== "string") return;
    if (message.type === SOCKET_TYPES.START) {
      await this.#startSpeaker(message, { local });
    } else if (message.type === SOCKET_TYPES.STOP) {
      this.#stopSpeaker(message);
    } else if (message.type === SOCKET_TYPES.STOP_ALL) {
      this.#stopAllSpeakers(message);
    }
  }

  async render() {
    if (!this.#overlayEnabled()) {
      this.remove();
      return;
    }

    if (getMaxSpeakers() < 2 && this.slots.right) this.slots.right = null;
    const context = {
      moduleId: MODULE_ID,
      scale: getOverlayScale(),
      reducedMotion: usesReducedAnimation(),
      manualPresentationEnabled: this.#manualPresentationEnabled(),
      slots: ["left", "right"].map(side => ({
        side,
        speaker: this.slots[side] ? this.#speakerContext(this.slots[side]) : null
      })),
      gm: game.user.isGM,
      gmSelectedName: await this.#getGmSpeakerName()
    };
    const html = await foundry.applications.handlebars.renderTemplate(TEMPLATES.SPEAKER_OVERLAY, context);
    const next = document.createRange().createContextualFragment(html).firstElementChild;
    if (!next) return;

    if (this.element) this.element.replaceWith(next);
    else document.body.appendChild(next);
    this.element = next;
    this.#applyOverlayLayout();
    this.#applyOverlayAppearance();
    this.element.classList.toggle("cots-reduced-motion", usesReducedAnimation());
    this.#activateOverlayListeners();
    Hooks.callAll(HOOKS.SPEAKERS_CHANGED, this.slots);
  }

  remove() {
    for (const timer of this.removeTimers.values()) window.clearTimeout(timer);
    this.removeTimers.clear();
    this.element?.remove();
    this.element = null;
  }

  async _onCreateChatMessage(message, options, userId) {
    if (!getSetting(SETTINGS.PRESENT_TEXT_CHAT) || !this.#overlayEnabled() || !isNarrativeChatMessage(message)) return;
    const user = chatUserFromMessage(message, userId);
    if (!user) return;

    const actor = await chatActorFromMessage(message, user);
    if (!actor) return;
    if (!user.isGM && !canUserSelectActor(actor, user)) return;

    const start = this.#buildLocalStartMessage(actor, "chat", "chat-message", user.id);
    const linger = Math.max(getLingerDuration(), 1.5);
    await this.#startSpeaker({ ...start, linger }, { local: true, allowInactiveUser: true });
    window.setTimeout(() => this.#stopSpeaker({
      userId: user.id,
      actorUuid: actor.uuid,
      linger
    }), 1200);
  }

  _onUserConnected(user, connected) {
    if (connected) return;
    for (const side of ["left", "right"]) {
      if (this.slots[side]?.userId === user.id) this.slots[side] = null;
    }
    this.render();
  }

  _onDeleteActor(actor) {
    for (const side of ["left", "right"]) {
      if (this.slots[side]?.actorUuid === actor.uuid) this.slots[side] = null;
    }
    this.render();
  }

  async #startSpeaker(message, { local = false, allowInactiveUser = false } = {}) {
    const validation = await this.#validateStartMessage(message, { local, allowInactiveUser });
    if (!validation) return;

    const { actor, snapshot, user } = validation;
    const key = actor?.uuid ?? snapshot.actorUuid;
    const existingSide = this.#findSpeakerSide(key);
    const side = existingSide ?? this.#chooseSide(snapshot.sidePreference);
    this.#clearTimer(key);

    this.slots[side] = {
      key,
      actor,
      snapshot,
      actorUuid: key,
      userId: user.id,
      side,
      active: true,
      mode: message.mode,
      startedAt: Number(message.startedAt) || Date.now(),
      lastActiveAt: Date.now(),
      linger: Number(message.linger) || getLingerDuration()
    };
    await this.render();
  }

  #stopSpeaker(message) {
    const userId = typeof message.userId === "string" ? message.userId : "";
    const actorUuid = typeof message.actorUuid === "string" ? message.actorUuid : "";
    const side = this.#findSpeakerSide(actorUuid, userId);
    if (!side || !this.slots[side]) return;

    const speaker = this.slots[side];
    speaker.active = false;
    speaker.lastActiveAt = Date.now();
    speaker.linger = Number(message.linger) || speaker.linger || getLingerDuration();
    this.#scheduleRemoval(speaker);
    this.render();
  }

  #stopAllSpeakers(message) {
    const user = typeof message.userId === "string" ? game.users.get(message.userId) : null;
    if (!user?.isGM) return;
    this.slots.left = null;
    this.slots.right = null;
    this.render();
  }

  async #validateStartMessage(message, { local = false, allowInactiveUser = false } = {}) {
    const user = typeof message.userId === "string" ? game.users.get(message.userId) : null;
    if (!user || (!allowInactiveUser && !local && !user.active)) return null;
    if (message.mode === "gm" && !user.isGM) return null;

    const actorUuid = typeof message.actorUuid === "string" ? message.actorUuid : "";
    const actor = await resolveActorUuid(actorUuid);
    if (!user.isGM && (!actor || !canUserSelectActor(actor, user))) return null;

    const snapshot = user.isGM
      ? sanitizeActorSnapshot(message.snapshot) ?? (actor ? buildActorSnapshot(actor) : null)
      : (actor ? buildActorSnapshot(actor) : null);
    if (!snapshot) return null;
    return { user, actor, snapshot };
  }

  #chooseSide(preference = "automatic") {
    const maxSpeakers = getMaxSpeakers();
    if (maxSpeakers <= 1) return "left";

    if ((preference === "left" || preference === "right") && !this.slots[preference]) return preference;
    if (!this.slots.left) return "left";
    if (!this.slots.right) return "right";
    if ((preference === "left" || preference === "right") && this.slots[preference] && !this.slots[preference].active) {
      return preference;
    }

    const entries = ["left", "right"].map(side => this.slots[side]).filter(Boolean);
    const inactive = entries.filter(entry => !entry.active).sort((a, b) => a.lastActiveAt - b.lastActiveAt);
    const replacement = inactive[0] ?? entries.sort((a, b) => a.startedAt - b.startedAt)[0];
    this.#clearTimer(replacement.key);
    return replacement.side;
  }

  #findSpeakerSide(actorUuid, userId = "") {
    for (const side of ["left", "right"]) {
      const speaker = this.slots[side];
      if (!speaker) continue;
      if (actorUuid && speaker.actorUuid === actorUuid) return side;
      if (!actorUuid && userId && speaker.userId === userId) return side;
    }
    return null;
  }

  #speakerContext(speaker) {
    const data = actorSpeakerData(speaker.actor, speaker.snapshot, speaker.side);
    return {
      ...data,
      active: speaker.active,
      lingering: !speaker.active,
      mode: speaker.mode
    };
  }

  #scheduleRemoval(speaker) {
    this.#clearTimer(speaker.key);
    const timeout = Math.max(0, speaker.linger * 1000);
    const timer = window.setTimeout(() => {
      if (this.slots[speaker.side]?.key === speaker.key && !this.slots[speaker.side].active) {
        this.slots[speaker.side] = null;
        this.removeTimers.delete(speaker.key);
        this.render();
      }
    }, timeout);
    this.removeTimers.set(speaker.key, timer);
  }

  #clearTimer(key) {
    const timer = this.removeTimers.get(key);
    if (timer) window.clearTimeout(timer);
    this.removeTimers.delete(key);
  }

  #activateOverlayListeners() {
    this.element.querySelectorAll("[data-action]").forEach(button => {
      button.addEventListener("click", event => this.#onOverlayAction(event));
    });
    this.element.querySelector("[data-cots-overlay-drag-handle]")?.addEventListener("pointerdown", event => this.#startOverlayDrag(event));
    this.element.querySelector("[data-cots-overlay-resize-handle]")?.addEventListener("pointerdown", event => this.#startOverlayResize(event));
  }

  #onOverlayAction(event) {
    const target = event.currentTarget;
    const action = target?.dataset?.action;
    if (action === "hide-overlay") {
      setSetting(SETTINGS.SPEAKER_OVERLAY_ENABLED, false);
    } else if (action === "open-gm-picker" && game.user.isGM) {
      this.openGmSpeakerPicker();
    } else if (action === "preview-gm" && game.user.isGM) {
      this.#getGmSpeakerActor().then(actor => this.previewActor(actor));
    } else if (action === "stop-all" && game.user.isGM) {
      this.socketController?.emitStopAll();
    }
  }

  openGmSpeakerPicker() {
    if (!game.user.isGM) return;
    this.gmPicker ??= new GmSpeakerPickerApp(this);
    this.gmPicker.render({ force: true });
  }

  #overlayEnabled() {
    return Boolean(getSetting(SETTINGS.ENABLE_SPEAKER_OVERLAY)) && Boolean(getSetting(SETTINGS.SPEAKER_OVERLAY_ENABLED));
  }

  #manualPresentationEnabled() {
    return Boolean(getSetting(SETTINGS.MANUAL_PRESENTATION_ENABLED));
  }

  #applyOverlayLayout() {
    const layout = getOverlayLayout();
    this.element.style.left = `${layout.left}px`;
    this.element.style.right = "auto";
    this.element.style.bottom = `${layout.bottom}px`;
    this.element.style.width = `${layout.width}px`;
    this.element.style.setProperty("--cots-overlay-scale", String(getOverlayScale()));
  }

  #applyOverlayAppearance() {
    const appearance = getOverlayAppearance();
    const background = hexToRgb(appearance.backgroundColor);
    this.element.style.setProperty("--cots-overlay-panel-bg", `rgba(${background.r}, ${background.g}, ${background.b}, ${appearance.panelOpacity})`);
    this.element.style.setProperty("--cots-overlay-gradient-start", appearance.gradientStart);
    this.element.style.setProperty("--cots-overlay-gradient-end", appearance.gradientEnd);
    this.element.style.setProperty("--cots-overlay-border-color", appearance.borderColor);
    this.element.style.setProperty("--cots-overlay-portrait-opacity", String(appearance.portraitOpacity));
  }

  #startOverlayDrag(event) {
    if (event.button !== 0) return;
    event.preventDefault();
    const layout = getOverlayLayout();
    this.dragState = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      layout
    };
    event.currentTarget.setPointerCapture?.(event.pointerId);
    this.element.classList.add("is-moving");
    const move = moveEvent => this.#continueOverlayDrag(moveEvent);
    const up = upEvent => {
      this.#endOverlayDrag(upEvent);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  #continueOverlayDrag(event) {
    if (!this.dragState || event.pointerId !== this.dragState.pointerId) return;
    const next = getConstrainedOverlayLayout({
      ...this.dragState.layout,
      left: this.dragState.layout.left + event.clientX - this.dragState.startX,
      bottom: this.dragState.layout.bottom - (event.clientY - this.dragState.startY)
    });
    this.element.style.left = `${next.left}px`;
    this.element.style.bottom = `${next.bottom}px`;
  }

  #endOverlayDrag(event) {
    if (!this.dragState || event.pointerId !== this.dragState.pointerId) return;
    event.currentTarget.releasePointerCapture?.(event.pointerId);
    const rect = this.element.getBoundingClientRect();
    this.element.classList.remove("is-moving");
    this.dragState = null;
    setOverlayLayout({
      left: rect.left,
      bottom: window.innerHeight - rect.bottom,
      width: rect.width
    });
  }

  #startOverlayResize(event) {
    if (event.button !== 0) return;
    event.preventDefault();
    const layout = getOverlayLayout();
    this.resizeState = {
      pointerId: event.pointerId,
      startX: event.clientX,
      layout
    };
    event.currentTarget.setPointerCapture?.(event.pointerId);
    this.element.classList.add("is-resizing");
    const move = moveEvent => this.#continueOverlayResize(moveEvent);
    const up = upEvent => {
      this.#endOverlayResize(upEvent);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  }

  #continueOverlayResize(event) {
    if (!this.resizeState || event.pointerId !== this.resizeState.pointerId) return;
    const next = getConstrainedOverlayLayout({
      ...this.resizeState.layout,
      width: this.resizeState.layout.width + event.clientX - this.resizeState.startX
    });
    this.element.style.width = `${next.width}px`;
  }

  #endOverlayResize(event) {
    if (!this.resizeState || event.pointerId !== this.resizeState.pointerId) return;
    event.currentTarget.releasePointerCapture?.(event.pointerId);
    const rect = this.element.getBoundingClientRect();
    this.element.classList.remove("is-resizing");
    this.resizeState = null;
    setOverlayLayout({
      left: rect.left,
      bottom: window.innerHeight - rect.bottom,
      width: rect.width
    });
  }

  async #getMainActor() {
    return resolveActorUuid(getCurrentUserConfig().mainActorUuid);
  }

  async #getGmSpeakerActor() {
    if (!game.user.isGM) return null;
    return resolveActorUuid(getGmSpeakerActorUuid());
  }

  async #getGmSpeakerName() {
    const actor = await this.#getGmSpeakerActor();
    return actor?.name ?? game.i18n.localize(`${MODULE_ID}.gmSpeaker.noneSelected`);
  }

  #buildLocalStartMessage(actor, mode, source, userId = game.user.id) {
    return {
      v: 1,
      type: SOCKET_TYPES.START,
      presentationId: randomId(),
      userId,
      actorUuid: actor.uuid,
      mode,
      source,
      startedAt: Date.now(),
      linger: getLingerDuration(),
      snapshot: buildActorSnapshot(actor)
    };
  }
}

export class GmSpeakerPickerApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: `${MODULE_ID}-gm-speaker-picker`,
    classes: [MODULE_ID, `${MODULE_ID}-gm-speaker-picker`],
    window: {
      title: `${MODULE_ID}.gmSpeaker.title`,
      icon: "fa-solid fa-theater-masks",
      resizable: true
    },
    position: {
      width: 460,
      height: 560
    },
    actions: {
      selectSpeaker: this.#selectSpeaker,
      clearSpeaker: this.#clearSpeaker,
      previewSpeaker: this.#previewSpeaker,
      stopAll: this.#stopAll,
      refreshIndex: this.#refreshIndex
    }
  };

  static PARTS = {
    main: {
      template: TEMPLATES.GM_SPEAKER_PICKER
    }
  };

  constructor(speakerController = game.cotsCharacterHud?.speaker, options = {}) {
    super(options);
    this.speakerController = speakerController;
    this.actorIndex = null;
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    if (!this.actorIndex) this.#buildActorIndex();
    const selected = await resolveActorUuid(getGmSpeakerActorUuid());
    return {
      ...context,
      actors: this.actorIndex,
      selected: selected ? {
        uuid: selected.uuid,
        name: selected.name,
        img: selected.img || "icons/svg/mystery-man.svg"
      } : null
    };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    const search = this.element.querySelector("[data-cots-gm-search]");
    search?.addEventListener("input", event => this.#filterActorRows(event.currentTarget.value));
  }

  #buildActorIndex() {
    this.actorIndex = game.actors
      .map(actor => ({
        uuid: actor.uuid,
        name: actor.name,
        type: actor.type,
        img: actor.img || "icons/svg/mystery-man.svg",
        search: `${actor.name} ${actor.type}`.toLocaleLowerCase(game.i18n.lang)
      }))
      .sort((a, b) => a.name.localeCompare(b.name, game.i18n.lang));
  }

  #filterActorRows(query) {
    const needle = String(query ?? "").toLocaleLowerCase(game.i18n.lang).trim();
    this.element.querySelectorAll("[data-cots-actor-row]").forEach(row => {
      const haystack = row.dataset.search ?? "";
      row.hidden = Boolean(needle) && !haystack.includes(needle);
    });
  }

  static async #selectSpeaker(event, target) {
    const uuid = target.dataset.actorUuid;
    if (!uuid) return;
    await setGmSpeakerActorUuid(uuid);
    this.speakerController?.render();
    this.render({ force: true });
  }

  static async #clearSpeaker() {
    await setGmSpeakerActorUuid("");
    this.speakerController?.render();
    this.render({ force: true });
  }

  static async #previewSpeaker() {
    const actor = await resolveActorUuid(getGmSpeakerActorUuid());
    await this.speakerController?.previewActor(actor);
  }

  static #stopAll() {
    this.speakerController?.socketController?.emitStopAll();
  }

  static #refreshIndex() {
    this.actorIndex = null;
    this.render({ force: true });
  }
}
