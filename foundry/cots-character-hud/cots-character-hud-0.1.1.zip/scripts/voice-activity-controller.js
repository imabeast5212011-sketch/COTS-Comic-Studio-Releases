import { MODULE_ID, SETTINGS } from "./constants.js";
import { clampNumber, getSetting, setSetting } from "./settings.js";

export class VoiceActivityController {
  constructor(speakerController) {
    this.speakerController = speakerController;
    this.stream = null;
    this.audioContext = null;
    this.analyser = null;
    this.source = null;
    this.buffer = null;
    this.frameId = null;
    this.speaking = false;
    this.lastAboveThreshold = 0;
    this.starting = false;
    this._boundConfigChanged = this._onConfigChanged.bind(this);
  }

  initialize() {
    Hooks.on(`${MODULE_ID}.configChanged`, this._boundConfigChanged);
    if (getSetting(SETTINGS.VOICE_ACTIVITY_ENABLED)) this.start();
  }

  destroy() {
    Hooks.off(`${MODULE_ID}.configChanged`, this._boundConfigChanged);
    this.stop();
  }

  async start() {
    if (this.stream || this.starting) return true;
    if (!navigator.mediaDevices?.getUserMedia) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.noMicrophoneApi`));
      await setSetting(SETTINGS.VOICE_ACTIVITY_ENABLED, false);
      return false;
    }

    this.starting = true;
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
      if (!getSetting(SETTINGS.VOICE_ACTIVITY_ENABLED)) {
        this.stream.getTracks().forEach(track => track.stop());
        this.stream = null;
        return false;
      }
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      this.audioContext = new AudioContextClass();
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 1024;
      this.analyser.smoothingTimeConstant = 0.12;
      this.source = this.audioContext.createMediaStreamSource(this.stream);
      this.source.connect(this.analyser);
      this.buffer = new Uint8Array(this.analyser.fftSize);
      this.#tick();
      ui.notifications?.info(game.i18n.localize(`${MODULE_ID}.notifications.voiceActivityStarted`));
      return true;
    } catch (error) {
      console.warn(`${MODULE_ID} | Voice activity setup failed`, error);
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.voiceActivityDenied`));
      await setSetting(SETTINGS.VOICE_ACTIVITY_ENABLED, false);
      return false;
    } finally {
      this.starting = false;
    }
  }

  async stop() {
    if (this.frameId) cancelAnimationFrame(this.frameId);
    this.frameId = null;
    if (this.speaking) await this.speakerController.stopVoiceActivity();
    this.speaking = false;
    this.lastAboveThreshold = 0;
    this.stream?.getTracks?.().forEach(track => track.stop());
    this.stream = null;
    this.source?.disconnect?.();
    this.source = null;
    this.analyser?.disconnect?.();
    this.analyser = null;
    await this.audioContext?.close?.();
    this.audioContext = null;
    this.buffer = null;
  }

  _onConfigChanged(key) {
    if (key === SETTINGS.VOICE_ACTIVITY_ENABLED) {
      if (getSetting(SETTINGS.VOICE_ACTIVITY_ENABLED)) this.start();
      else this.stop();
    }
  }

  #tick() {
    this.frameId = requestAnimationFrame(() => this.#tick());
    if (!this.analyser || !this.buffer) return;

    this.analyser.getByteTimeDomainData(this.buffer);
    let sum = 0;
    for (let i = 0; i < this.buffer.length; i += 1) {
      const centered = (this.buffer[i] - 128) / 128;
      sum += centered * centered;
    }
    const rms = Math.sqrt(sum / this.buffer.length);
    const threshold = clampNumber(getSetting(SETTINGS.VOICE_ACTIVITY_THRESHOLD), 0.01, 0.2, 0.055);
    const releaseDelay = clampNumber(getSetting(SETTINGS.VOICE_ACTIVITY_RELEASE_DELAY), 0.2, 3, 0.65) * 1000;
    const now = performance.now();

    if (rms >= threshold) {
      this.lastAboveThreshold = now;
      if (!this.speaking) {
        this.speaking = true;
        this.speakerController.startVoiceActivity();
      }
    } else if (this.speaking && now - this.lastAboveThreshold >= releaseDelay) {
      this.speaking = false;
      this.speakerController.stopVoiceActivity();
    }
  }
}
