import { MODULE_ID, SOCKET_EVENT, SOCKET_TYPES, randomId } from "./constants.js";
import { buildActorSnapshot, canUserSelectActor } from "./actor-data-adapter.js";
import { getLingerDuration } from "./settings.js";

export class SocketController {
  constructor(speakerController) {
    this.speakerController = speakerController;
    this._boundHandleSocketMessage = this._handleSocketMessage.bind(this);
  }

  initialize() {
    if (!game.socket) {
      console.warn(`${MODULE_ID} | Foundry socket is unavailable.`);
      return;
    }
    game.socket.on(SOCKET_EVENT, this._boundHandleSocketMessage);
  }

  destroy() {
    game.socket?.off?.(SOCKET_EVENT, this._boundHandleSocketMessage);
  }

  async emitStart(actor, { mode = "main", source = "keybind", chatText = "", linger = getLingerDuration() } = {}) {
    if (!this.#canBroadcastActor(actor, mode)) return false;
    const message = {
      v: 1,
      type: SOCKET_TYPES.START,
      presentationId: randomId(),
      userId: game.user.id,
      actorUuid: actor.uuid,
      mode,
      source,
      startedAt: Date.now(),
      linger,
      snapshot: buildActorSnapshot(actor),
      chatText
    };
    game.socket.emit(SOCKET_EVENT, message);
    this.speakerController.handleSocketMessage(message, { local: true });
    return true;
  }

  async emitStop(actor, { mode = "main", linger = getLingerDuration() } = {}) {
    if (!actor) return false;
    const message = {
      v: 1,
      type: SOCKET_TYPES.STOP,
      presentationId: randomId(),
      userId: game.user.id,
      actorUuid: actor.uuid,
      mode,
      stoppedAt: Date.now(),
      linger
    };
    game.socket.emit(SOCKET_EVENT, message);
    this.speakerController.handleSocketMessage(message, { local: true });
    return true;
  }

  emitStopAll() {
    if (!game.user.isGM) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.gmOnly`));
      return false;
    }
    const message = {
      v: 1,
      type: SOCKET_TYPES.STOP_ALL,
      presentationId: randomId(),
      userId: game.user.id,
      stoppedAt: Date.now()
    };
    game.socket.emit(SOCKET_EVENT, message);
    this.speakerController.handleSocketMessage(message, { local: true });
    return true;
  }

  emitStopExceptGm(actor = null) {
    if (!game.user.isGM) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.gmOnly`));
      return false;
    }
    const message = {
      v: 1,
      type: SOCKET_TYPES.STOP_EXCEPT_GM,
      presentationId: randomId(),
      userId: game.user.id,
      actorUuid: actor?.uuid ?? "",
      stoppedAt: Date.now()
    };
    game.socket.emit(SOCKET_EVENT, message);
    this.speakerController.handleSocketMessage(message, { local: true });
    return true;
  }

  _handleSocketMessage(message) {
    this.speakerController.handleSocketMessage(message, { local: false });
  }

  #canBroadcastActor(actor, mode) {
    if (!actor) {
      ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.noSpeakerActor`));
      return false;
    }
    if (mode === "gm" && !game.user.isGM) return false;
    if (game.user.isGM || canUserSelectActor(actor, game.user)) return true;
    ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.noActorPermission`));
    return false;
  }
}
