# Manual Test Checklist

Use a Foundry VTT v14 world running the D&D 5e system.

1. Enable the module and confirm no console-breaking startup errors.
2. As a non-GM player, open HUD configuration and confirm only owned Actors are selectable.
3. Select one main Actor and confirm portrait, name, HP, temp HP, AC, movement, and spell slots or resources display.
4. Change HP, AC, movement, spell slots, or resources on the Actor and confirm the HUD refreshes.
5. Add at least three companion Actors and confirm the tray remains compact and scrolls horizontally.
6. Remove a companion from the tray and confirm the Actor/token still exists.
7. Put selected Actors' tokens on the active scene. Single-click HUD portraits to select, Shift-click to pan, and double-click to open sheets.
8. Assign keybindings in Configure Controls. Hold the main speaker key and confirm other clients see the portrait and name.
9. Release the key and confirm the portrait lingers, fades, and clears.
10. Have two users speak at once and confirm left/right two-speaker presentation.
11. Trigger a third speaker and confirm replacement follows least-recent inactive or least-recent-started active behavior.
12. As GM, select an NPC in the GM speaker picker, preview locally, hold the GM speaker key, and stop all presentations.
13. Configure an Actor cinematic display name, portrait, accent color, side preference, and flip state. Confirm the HUD and overlay use them.
14. Post a normal chat message and confirm the speaker briefly appears. Post a roll and confirm it is ignored.
15. Enable Auto Voice Presentation, grant microphone permission, speak, and confirm the main Actor appears. Stop speaking and confirm the portrait lingers then fades.
16. Raise Voice Activity Threshold and confirm room noise is less likely to trigger presentation.
17. Disable Manual Speaker Presentation and confirm HUD/keybind presentation does not start while auto voice can still work.
18. Move and resize the speaker overlay and confirm position and width persist after reload.
19. Change overlay gradient, background color, border color, panel opacity, and portrait opacity, then confirm the overlay updates.
20. Toggle reduced animation and speaker overlay client settings and confirm they persist.
