export const MODULE_ID = "cots-character-hud";
export const MODULE_TITLE = "COTS Character HUD";
export const SOCKET_EVENT = `module.${MODULE_ID}`;

export const FLAGS = Object.freeze({
  USER_CONFIG: "userConfig",
  ACTOR_CONFIG: "actorConfig"
});

export const SETTINGS = Object.freeze({
  ENABLE_PLAYER_HUD: "enablePlayerHud",
  ENABLE_SPEAKER_OVERLAY: "enableSpeakerOverlay",
  MAX_SPEAKERS: "maxSpeakers",
  DEFAULT_LINGER: "defaultLingerDuration",
  ALLOW_PLAYER_ACCENTS: "allowPlayerAccentColors",
  GM_ONLY_CINEMATIC_CONFIG: "gmOnlyCinematicConfig",
  ALLOW_CLIENT_LINGER_OVERRIDE: "allowClientLingerOverride",
  PRESENT_TEXT_CHAT: "presentTextChat",
  HUD_ENABLED: "hudEnabled",
  HUD_POSITION: "hudPosition",
  HUD_SCALE: "hudScale",
  COMPANION_TRAY_COLLAPSED: "companionTrayCollapsed",
  SPEAKER_OVERLAY_ENABLED: "speakerOverlayEnabled",
  SPEAKER_OVERLAY_SCALE: "speakerOverlayScale",
  SPEAKER_LINGER_OVERRIDE: "speakerLingerOverride",
  REDUCED_ANIMATION: "reducedAnimation",
  MANUAL_PRESENTATION_ENABLED: "manualPresentationEnabled",
  VOICE_ACTIVITY_ENABLED: "voiceActivityEnabled",
  VOICE_ACTIVITY_THRESHOLD: "voiceActivityThreshold",
  VOICE_ACTIVITY_RELEASE_DELAY: "voiceActivityReleaseDelay",
  OVERLAY_LAYOUT: "overlayLayout",
  OVERLAY_BACKGROUND_COLOR: "overlayBackgroundColor",
  OVERLAY_GRADIENT_START: "overlayGradientStart",
  OVERLAY_GRADIENT_END: "overlayGradientEnd",
  OVERLAY_BORDER_COLOR: "overlayBorderColor",
  OVERLAY_PANEL_OPACITY: "overlayPanelOpacity",
  OVERLAY_PORTRAIT_OPACITY: "overlayPortraitOpacity"
});

export const KEYBINDINGS = Object.freeze({
  HOLD_MAIN: "holdMainSpeaker",
  TOGGLE_MAIN: "toggleMainSpeaker",
  HOLD_GM: "holdGmSpeaker"
});

export const SOCKET_TYPES = Object.freeze({
  START: "speaker:start",
  STOP: "speaker:stop",
  STOP_ALL: "speaker:stop-all"
});

export const TEMPLATES = Object.freeze({
  HUD: `modules/${MODULE_ID}/templates/hud.html`,
  HUD_CONFIG: `modules/${MODULE_ID}/templates/hud-config.html`,
  SPEAKER_OVERLAY: `modules/${MODULE_ID}/templates/speaker-overlay.html`,
  GM_SPEAKER_PICKER: `modules/${MODULE_ID}/templates/gm-speaker-picker.html`,
  ACTOR_CONFIG: `modules/${MODULE_ID}/templates/actor-config.html`
});

export const HOOKS = Object.freeze({
  CONFIG_CHANGED: `${MODULE_ID}.configChanged`,
  USER_CONFIG_CHANGED: `${MODULE_ID}.userConfigChanged`,
  SPEAKERS_CHANGED: `${MODULE_ID}.speakersChanged`
});

export function localize(key) {
  return game.i18n.localize(`${MODULE_ID}.${key}`);
}

export function format(key, data = {}) {
  return game.i18n.format(`${MODULE_ID}.${key}`, data);
}

export function ownerPermissionLevel() {
  return globalThis.CONST?.DOCUMENT_OWNERSHIP_LEVELS?.OWNER ?? 3;
}

export function randomId() {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}
