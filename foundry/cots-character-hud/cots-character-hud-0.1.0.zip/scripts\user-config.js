import { FLAGS, HOOKS, MODULE_ID, SETTINGS } from "./constants.js";
import { getSetting, setSetting } from "./settings.js";

const DEFAULT_USER_CONFIG = Object.freeze({
  mainActorUuid: "",
  companionActorUuids: [],
  hudExpanded: true,
  companionTrayCollapsed: undefined,
  gmSpeakerActorUuid: ""
});

function normalizeUuidArray(value) {
  if (!Array.isArray(value)) return [];
  return Array.from(new Set(value.filter(uuid => typeof uuid === "string" && uuid.trim())));
}

export function getCurrentUserConfig() {
  const flag = game.user?.getFlag(MODULE_ID, FLAGS.USER_CONFIG) ?? {};
  const companionTrayCollapsed = typeof flag.companionTrayCollapsed === "boolean"
    ? flag.companionTrayCollapsed
    : Boolean(getSetting(SETTINGS.COMPANION_TRAY_COLLAPSED));

  return {
    ...DEFAULT_USER_CONFIG,
    ...flag,
    mainActorUuid: typeof flag.mainActorUuid === "string" ? flag.mainActorUuid : "",
    companionActorUuids: normalizeUuidArray(flag.companionActorUuids),
    hudExpanded: flag.hudExpanded !== false,
    companionTrayCollapsed,
    gmSpeakerActorUuid: typeof flag.gmSpeakerActorUuid === "string" ? flag.gmSpeakerActorUuid : ""
  };
}

export async function updateCurrentUserConfig(patch) {
  const current = getCurrentUserConfig();
  const next = {
    ...current,
    ...patch,
    companionActorUuids: normalizeUuidArray(patch.companionActorUuids ?? current.companionActorUuids)
  };

  await game.user.setFlag(MODULE_ID, FLAGS.USER_CONFIG, next);
  if (typeof patch.companionTrayCollapsed === "boolean") {
    await setSetting(SETTINGS.COMPANION_TRAY_COLLAPSED, patch.companionTrayCollapsed);
  }
  Hooks.callAll(HOOKS.USER_CONFIG_CHANGED, next, current);
  Hooks.callAll(HOOKS.CONFIG_CHANGED, "userConfig", next);
  return next;
}

export async function addCompanionActor(uuid) {
  if (!uuid) return getCurrentUserConfig();
  const current = getCurrentUserConfig();
  const companionActorUuids = normalizeUuidArray([...current.companionActorUuids, uuid]);
  return updateCurrentUserConfig({ companionActorUuids });
}

export async function removeCompanionActor(uuid) {
  const current = getCurrentUserConfig();
  const companionActorUuids = current.companionActorUuids.filter(existing => existing !== uuid);
  return updateCurrentUserConfig({ companionActorUuids });
}
