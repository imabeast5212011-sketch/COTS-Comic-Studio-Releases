import { MODULE_ID, MODULE_TITLE } from "./constants.js";
import { ActorCinematicConfig, registerActorConfigHooks } from "./actor-config.js";
import { HudConfigApp, HudController } from "./hud-controller.js";
import { GmSpeakerPickerApp, SpeakerController } from "./speaker-controller.js";
import { SocketController } from "./socket-controller.js";
import { registerKeybindings, registerSettings, registerSettingsMenus } from "./settings.js";
import { VoiceActivityController } from "./voice-activity-controller.js";

Hooks.once("init", () => {
  registerSettings();
  registerSettingsMenus({ HudConfigApp, GmSpeakerPickerApp });
  registerKeybindings();
  registerActorConfigHooks();
  console.log(`${MODULE_TITLE} | Initialized.`);
});

Hooks.once("ready", () => {
  const speaker = new SpeakerController();
  const socket = new SocketController(speaker);
  const hud = new HudController(speaker);
  const voice = new VoiceActivityController(speaker);

  speaker.setSocketController(socket);
  socket.initialize();
  speaker.initialize();
  hud.initialize();
  voice.initialize();

  game.cotsCharacterHud = {
    moduleId: MODULE_ID,
    hud,
    speaker,
    socket,
    voice,
    apps: {
      ActorCinematicConfig,
      HudConfigApp,
      GmSpeakerPickerApp
    },
    openHudConfig: () => hud.openConfig(),
    openGmSpeakerPicker: () => speaker.openGmSpeakerPicker()
  };

  if (game.system?.id !== "dnd5e") {
    ui.notifications?.warn(game.i18n.localize(`${MODULE_ID}.notifications.dnd5eOnly`));
  }
});
